//
//  BarberTableViewCell.h
//  Barber
//
//  Created by Vadim Marina on 8/20/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPFloatRatingView.h"

@interface BarberTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet       UIImageView          *barberImage;
@property (weak, nonatomic) IBOutlet       UIImageView          *userImage;
@property (weak, nonatomic) IBOutlet       UILabel              *barberName;
@property (weak, nonatomic) IBOutlet       UILabel              *reivewCount;
@property (weak, nonatomic) IBOutlet       UILabel              *barberAddress;
@property (weak, nonatomic) IBOutlet       UILabel              *price;
@property (weak, nonatomic) IBOutlet       UIButton             *btnLike;
@property (weak, nonatomic) IBOutlet       TPFloatRatingView    *barberRating;
@property  BOOL                                                 likeStatus;

@end
