//
//  HomeDetailViewController.m
//  Barber
//
//  Created by Vadim Marina on 8/20/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "HomeDetailViewController.h"
#import "KMMovieDetailsCell.h"
#import "KMMovieDetailsDescriptionCell.h"
#import "KMMovieDetailsSimilarMoviesCell.h"
#import "_KMSimilarMoviesCollectionViewCell.h"
#import "KMMovieDetailsCommentsCell.h"
#import "KMMovieDetailsViewAllCommentsCell.h"
#import "KMComposeCommentCell.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "TPFloatRatingView.h"
#import "BarberModel.h"
#import <UIImageView+WebCache.h>
#import "AppDelegate.h"
#import <THDatePickerViewController.h>
#import "WSDatePickerView.h"
#import "BookNowViewController.h"

#define RGB(x,y,z) [UIColor colorWithRed:x/255.0 green:y/255.0 blue:z/255.0 alpha:1.0]

@interface HomeDetailViewController () <TPFloatRatingViewDelegate ,MKMapViewDelegate,THDatePickerDelegate>
{
    NSArray *fullMenuArray;
}

@property (weak, nonatomic) IBOutlet KMScrollingHeaderView* scrollingHeaderView;
@property (weak, nonatomic) IBOutlet UIView                 *navigationBarView;
@property (weak, nonatomic) IBOutlet UILabel                *shopTitle;

@property (strong, nonatomic) NSArray                       *similarDataArray;
@property (strong, nonatomic) NSMutableArray                *itemArray;

@property int curIndex;
@property (nonatomic, strong) THDatePickerViewController * datePicker;
@property (nonatomic, retain) NSDate * curDate;
@property (nonatomic, retain) NSDateFormatter * formatter;


@end

@implementation HomeDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.curDate = [NSDate date];
    self.formatter = [[NSDateFormatter alloc] init];
    [_formatter setDateFormat:@"dd/MM/yyyy --- HH:mm"];
   
    
    
    _itemArray = [[NSMutableArray alloc] init];
    _similarDataArray= [[NSMutableArray alloc] init];
    [self loadData];
    [self setupNavbarButtons];
    [self setupDetailsPageView];

    // Do any additional setup after loading the view.
}

- (void)loadData
{
    BarberModel *data1 = [BarberModel new];
    data1.barberThumbImg = @"barber1";
    data1.barberUserImg = @"user1";
    data1.rate = @"5.0";
    data1.price = @"12";
    data1.barberAddress = @"67 Oak St6E, Chicago, 60611, USA";
    data1.reviewCount = @"59";
    data1.barberName = @"Olesya Bob";
    data1.titleName = @"Twin Scissors Barber";
    
    BarberModel *data2 = [BarberModel new];
    data2.barberThumbImg = @"barber2";
    data2.barberUserImg = @"user2";
    data2.rate = @"4.5";
    data2.price = @"26,900";
    data2.barberAddress = @"576 Torrence Ave City, 60409, USA";
    data2.reviewCount = @"13";
    data2.barberName = @"Stefania Marina";
    data2.titleName = @"Buzz Cuts Barber";
    
    
    BarberModel *data3 = [BarberModel new];
    data3.barberThumbImg = @"barber3";
    data3.barberUserImg = @"user3";
    data3.rate = @"4.8";
    data3.price = @"30";
    data3.barberAddress = @"504 Allendale Rd, Houston 77017, USA";
    data3.reviewCount = @"32";
    data3.barberName = @"Cesla Amarelle";
    data3.titleName = @"The Men's Mane";
    
    BarberModel *data4 = [BarberModel new];
    data4.barberThumbImg = @"barber4";
    data4.barberUserImg = @"user4";
    data4.rate = @"3.9";
    data4.price = @"30";
    data4.barberAddress = @"Saticoy St, CA 91306, USA";
    data4.reviewCount = @"14";
    data4.barberName = @"Denis Obuz";
    data4.titleName = @"Fade Zone Barber";
    
    BarberModel *data5 = [BarberModel new];
    data5.barberThumbImg = @"barber5";
    data5.barberUserImg = @"user5";
    data5.rate = @"5.0";
    data5.price = @"15";
    data5.barberAddress = @"5922 Yorktown Blvd, Tx 78414, USA";
    data5.reviewCount = @"30";
    data5.barberName = @"Samuel Noodlez";
    data5.titleName = @"The Mustached Man";
    
    BarberModel *data6 = [BarberModel new];
    data6.barberThumbImg = @"barber6";
    data6.barberUserImg = @"user6";
    data6.rate = @"4.4";
    data6.price = @"22";
    data6.barberAddress = @"1075 Main St, Holbrook, NY 11641, USA";
    data6.reviewCount = @"17";
    data6.barberName = @"Doris Muller";
    data6.titleName = @"Sideburns Barber";
    
    BarberModel *data7 = [BarberModel new];
    data7.barberThumbImg = @"barber7";
    data7.barberUserImg = @"user7";
    data7.rate = @"5.0";
    data7.price = @"30";
    data7.barberAddress = @"10th Ave, New York 10019, USA";
    data7.reviewCount = @"25";
    data7.barberName = @"Alex Capus";
    data7.titleName = @"The Humble Barber";
    
    BarberModel *data8 = [BarberModel new];
    data8.barberThumbImg = @"barber8";
    data8.barberUserImg = @"user8";
    data8.rate = @"4.7";
    data8.price = @"36";
    data8.barberAddress = @"202 Old Cutler Rd, FL 33103, USA";
    data8.reviewCount = @"7";
    data8.barberName = @"Nadine Tokar";
    data8.titleName = @"Raceway Barber";
    
    BarberModel *data9 = [BarberModel new];
    data9.barberThumbImg = @"barber9";
    data9.barberUserImg = @"user9";
    data9.rate = @"4.5";
    data9.price = @"20";
    data9.barberAddress = @"1002 Main St,Radford, 24114, USA";
    data9.reviewCount = @"26";
    data9.barberName = @"Anina Schar";
    data9.titleName = @"Bob the Barber";
    
    self.similarDataArray = [NSArray arrayWithObjects:data1, data2, data3,data4,data5,data6,data7,data8,data9,nil];

    
}

- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    self.navigationController.interactivePopGestureRecognizer.delegate = nil;
    self.scrollingHeaderView.navbarView = self.navigationBarView;
    
    [super viewWillAppear:animated];
}

#pragma mark - Setup Methods

- (void)setupDetailsPageView
{
    self.scrollingHeaderView.tableView.dataSource = self;
    self.scrollingHeaderView.tableView.delegate = self;
    self.scrollingHeaderView.delegate = self;
    self.scrollingHeaderView.tableView.separatorColor = [UIColor clearColor];
    self.scrollingHeaderView.headerImageViewContentMode = UIViewContentModeScaleToFill;
    
    [self.scrollingHeaderView reloadScrollingHeader];
}


- (void)setupNavbarButtons
{
    UIButton *buttonBack = [UIButton buttonWithType:UIButtonTypeCustom];
    
    buttonBack.frame = CGRectMake(10, 31, 22, 22);
    [buttonBack setImage:[UIImage imageNamed:@"back_icon"] forState:UIControlStateNormal];
    [buttonBack addTarget:self action:@selector(popViewController:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:buttonBack];
    
    UIButton *shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    shareButton.frame = CGRectMake(370, 26, 30, 30);
    [shareButton setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    [shareButton addTarget:self action:@selector(ShareViewController:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:shareButton];
    
    
    self.shopTitle.text = _selData[@"barberName"];
}

- (IBAction)popViewController:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)ShareViewController:(id)sender
{
    NSString *theMessage = _selData[@"barberName"];
    NSArray *items = @[theMessage];
    
    // build an activity view controller
    UIActivityViewController *controller = [[UIActivityViewController alloc]initWithActivityItems:items applicationActivities:nil];
    
    // exclude several items (for example, Facepuke and Shitter)
    NSArray *excluded = @[UIActivityTypePostToFacebook, UIActivityTypePostToTwitter];
    controller.excludedActivityTypes = excluded;
    
    // and present it
    [self presentActivityController:controller];
    
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section==0)
    {
        return 3;
    }
    else{
        NSLog(@"cont == %lu",(unsigned long)_itemArray.count);
        return _itemArray.count;
        
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // A much nicer way to deal with this would be to extract this code to a factory class, that would take care of building the cells.
    UITableViewCell* cell = nil;
    
    if (indexPath.section == 0) {
        switch (indexPath.row)
        {
            case 0:
            {
                KMMovieDetailsCell *detailsCell = [tableView dequeueReusableCellWithIdentifier:@"KMMovieDetailsCell"];
                
                if(detailsCell == nil)
                    detailsCell = [KMMovieDetailsCell movieDetailsCell];
                
                detailsCell.barberName.text = _selData[@"barberName"];
                PFUser *postUser = _selData[@"baber"];
                detailsCell.address.text = _selData[@"barberAddress"];
                
                detailsCell.rate.text = [NSString stringWithFormat:@"%@ Reviews",_selData[@"reviewCount"]];
                
                detailsCell.ratingView.delegate = self;
                detailsCell.ratingView.emptySelectedImage = [UIImage imageNamed:@"unsel_Star"];
                detailsCell.ratingView.fullSelectedImage = [UIImage imageNamed:@"sel_Star"];
                detailsCell.ratingView.contentMode = UIViewContentModeScaleAspectFill;
                detailsCell.ratingView.maxRating = 5;
                detailsCell.ratingView.minRating = 1;
                NSString *str = _selData[@"rate"];
                detailsCell.ratingView.rating = (CGFloat)[str floatValue];
                detailsCell.ratingView.editable = NO;
                detailsCell.ratingView.halfRatings = NO;
                detailsCell.ratingView.floatRatings = YES;
                
                detailsCell.price.text = [NSString stringWithFormat:@"$%@",_selData[@"price"]];
                                
                PFFile *profileImg = postUser[PF_USER_PICTURE];
                
     
                if (profileImg == nil) {
                    detailsCell.posterImageView.image = [UIImage imageNamed:@"demoUser.png"];
                    detailsCell.genresLabel.text = @"Unknown";
                }
                else
                {
                    [detailsCell.posterImageView sd_setImageWithURL:[NSURL URLWithString:profileImg.url] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
                        
                    } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
                        
                    }];
                    detailsCell.genresLabel.text = postUser[PF_USER_FULLNAME];
                }

                
                [detailsCell.bookNow addTarget:self action:@selector(btnGoBook:) forControlEvents:UIControlEventTouchUpInside];
                
                
                cell = detailsCell;
                
                break;
            }
            case 1:
            {
                KMMovieDetailsCommentsCell *mapCell = [tableView dequeueReusableCellWithIdentifier:@"KMMovieDetailsCommentsCell"];
                if(mapCell == nil)
                    mapCell = [KMMovieDetailsCommentsCell movieDetailsCommentsCell];
                
                mapCell.mapView.scrollEnabled = false;
                mapCell.mapView.userInteractionEnabled = false;
                
                [mapCell performSearch:_selData[@"barberAddress"]];

                [mapCell.btnDirection addTarget:self action:@selector(btnDirection:) forControlEvents:UIControlEventTouchUpInside];
                
                cell = mapCell;
                
                break;
                
                
            }
            case 2:
            {
                KMMovieDetailsSimilarMoviesCell *contributionCell = [tableView dequeueReusableCellWithIdentifier:@"KMMovieDetailsSimilarMoviesCell"];
                
                if(contributionCell == nil)
                    contributionCell = [KMMovieDetailsSimilarMoviesCell movieDetailsSimilarMoviesCell];
                
                [contributionCell.viewAllSimilarMoviesButton addTarget:self action:@selector(viewAllSimilarMoviesButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
                
                cell = contributionCell;
                
                break;
            }
        }
        
    }
    else
    {
        KMMovieDetailsCommentsCell *foodCell = [tableView dequeueReusableCellWithIdentifier:@"KMMovieDetailsCommentsCell"];
        
        if(foodCell == nil)
            foodCell = [KMMovieDetailsCommentsCell movieDetailsCommentsCell];
        
        cell = foodCell;
        
    }
    
    return cell;
}

- (void)presentActivityController:(UIActivityViewController *)controller {
    
    // for iPad: make the presentation a Popover
    controller.modalPresentationStyle = UIModalPresentationPopover;
    [self presentViewController:controller animated:YES completion:nil];
    
    UIPopoverPresentationController *popController = [controller popoverPresentationController];
    popController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    popController.barButtonItem = self.navigationItem.leftBarButtonItem;
    
    // access the completion handler
    controller.completionWithItemsHandler = ^(NSString *activityType,
                                              BOOL completed,
                                              NSArray *returnedItems,
                                              NSError *error){
        // react to the completion
        if (completed) {
            
            // user shared an item
            NSLog(@"We used activity type%@", activityType);
            
        } else {
            
            // user cancelled
            NSLog(@"We didn't want to share anything after all.");
        }
        
        if (error) {
            NSLog(@"An Error occured: %@, %@", error.localizedDescription, error.localizedFailureReason);
        }
    };
}



- (IBAction)btnGoBook:(id)sender
{
    
    if ([PFUser currentUser].objectId == nil)
    {
        UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UIViewController *one = [board instantiateViewControllerWithIdentifier:@"loginVC"];
        UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:one];
        nc.navigationBar.hidden = YES;
        [self.navigationController presentModalViewController:nc animated:YES];
        
    }
    else
    {
        UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        BookNowViewController    *vc = [board instantiateViewControllerWithIdentifier:@"bookNowVC"];
        vc.barber_Name = _selData[@"barberName"];
        vc.barber_Time = @"10:00 AM - 4:00 PM";
        vc.barber_Price = _selData[@"price"];
        vc.brand_Image = _selData[@"brandImage"];
        
        [self.navigationController pushViewController:vc animated:YES];
    }
    
    
}


- (IBAction)btnDirection:(id)sender
{
    

    // this uses an address for the destination.  can use lat/long, too with %f,%f format
    NSString* address = @"202 Old Cutler Rd, FL 33103, USA";
    NSString* url = [NSString stringWithFormat: @"http://maps.google.com/maps?saddr=%f,%f&daddr=%@",
                     34.0442592, -118.4195401,
                     [address stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    [[UIApplication sharedApplication] openURL: [NSURL URLWithString: url]];

}

#pragma mark - THDatePickerDelegate

- (void)datePickerDonePressed:(THDatePickerViewController *)datePicker {
    self.curDate = datePicker.date;
//    [self refreshTitle];
    [self dismissSemiModalView];
}

- (void)datePickerCancelPressed:(THDatePickerViewController *)datePicker {
    [self dismissSemiModalView];
}

- (void)datePicker:(THDatePickerViewController *)datePicker selectedDate:(NSDate *)selectedDate {
    NSLog(@"Date selected: %@",[_formatter stringFromDate:selectedDate]);
}


- (IBAction)btnVideoPlay:(id)sender
{
    //    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    //    VideoPlayViewController *vc = [board instantiateViewControllerWithIdentifier:@"VideoPlayVC"];
    //    [self presentViewController:vc animated:YES completion:nil];
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    if (indexPath.section == 1) {
        
        self.curIndex = (int)indexPath.row;
        
        //        PFObject *obj = [_itemArray objectAtIndex:self.curIndex];
        //
        //        UIStoryboard     *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        //        AddCartViewController *vc = [board instantiateViewControllerWithIdentifier:@"addCartVC"];
        //        vc.foodTitle = obj[@"posterName"];
        //        vc.desString = obj[@"des"];
        //        vc.imgPath = obj[@"foodImg"];
        //        vc.priceString = obj[@"price"];
        //        vc.strRestName = obj[@"posterName"];
        //        [self presentViewController:vc animated:YES completion:nil];
        
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.contentView.backgroundColor = [UIColor clearColor];
    
    if ([cell isKindOfClass:[KMMovieDetailsSimilarMoviesCell class]])
    {
        KMMovieDetailsSimilarMoviesCell* similarMovieCell = (KMMovieDetailsSimilarMoviesCell*)cell;
        
        [similarMovieCell setCollectionViewDataSourceDelegate:self index:indexPath.row];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // A much nicer way to deal with this would be to extract this code to a factory class, that would return the cells' height.
    CGFloat height = 0;
    
    if (indexPath.section == 0) {
        switch (indexPath.row)
        {
            case 0:
            {
                height = 327;
                break;
            }
            case 1:
            {
                height = 273;
                break;
            }
            case 2:
            {
                if ([_similarDataArray count] == 0)
                {
                    height = 0;
                }
                else
                {
                    height = 250;
                }
                break;
            }
        }
        
    }
    else
    {
        height = 250;
    }
    
    
    return height;
}

#pragma mark - Leave a Commnet

- (void)writeComment:(id)sender
{
    
}


#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section;
{
    return [_similarDataArray count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    _KMSimilarMoviesCollectionViewCell* cell = (_KMSimilarMoviesCollectionViewCell*)[collectionView dequeueReusableCellWithReuseIdentifier:@"_KMSimilarMoviesCollectionViewCell" forIndexPath:indexPath];
    
    //    PFObject *obj = [_itemArray objectAtIndex:indexPath.row];
    //
    //    [cell.cellImageView sd_setImageWithURL:[NSURL URLWithString:obj[@"foodImg"]] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
    //
    //
    //    } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
    //
    //
    //    }];
    
    BarberModel *similarData = nil;
    similarData = [_similarDataArray objectAtIndex:indexPath.row];
    
    cell.cellImageView.image = [UIImage imageNamed:similarData.barberThumbImg];
    
    cell.barberRating.delegate = self;
    cell.barberRating.emptySelectedImage = [UIImage imageNamed:@"unsel_Star"];
    cell.barberRating.fullSelectedImage = [UIImage imageNamed:@"sel_Star"];
    cell.barberRating.contentMode = UIViewContentModeScaleAspectFill;
    cell.barberRating.maxRating = 5;
    cell.barberRating.minRating = 1;
    NSString *str = similarData.rate;
    cell.barberRating.rating = (CGFloat)[str floatValue];
    cell.barberRating.editable = NO;
    cell.barberRating.halfRatings = NO;
    cell.barberRating.floatRatings = YES;
    cell.reivewCount.text = [NSString stringWithFormat:@"%@ Reviews",similarData.reviewCount];

    cell.barberName.text = similarData.titleName;

    return cell;
}

#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath;
{
    
//    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    
//    ExpDetailViewController *vc = (ExpDetailViewController*)[storyboard instantiateViewControllerWithIdentifier:@"expDetailVC"];
//    
//    
//    
//    //    self.curIndex = (int)indexPath.row;
//    //    PFObject *obj = [_itemArray objectAtIndex:self.curIndex];
//    //    vc.obj = obj;
//    
//    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - KMScrollingHeaderViewDelegate

- (void)detailsPage:(KMScrollingHeaderView *)detailsPageView headerImageView:(UIImageView *)imageView
{
    //    [imageView sd_setImageWithURL:[NSURL URLWithString:_obj[@"foodImg"]] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
    //        
    //        
    //    } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
    //        
    //        
    //    }];
    
    PFFile *profileImg = _selData[@"brandImage"];
    
    [imageView sd_setImageWithURL:[NSURL URLWithString:profileImg.url] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        
    } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
        
    }];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
