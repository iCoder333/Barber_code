//
//  ConfirmViewController.h
//  Barber
//
//  Created by Vadim Marina on 8/20/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConfirmViewController : UIViewController <UITextFieldDelegate>
{
    NSTimer *_timer;
}

@property (weak, nonatomic) IBOutlet UITextField            *confirmCode;
@property (weak,nonatomic) IBOutlet UIButton                *verify_button;
@property (weak,nonatomic) IBOutlet UIActivityIndicatorView *loadHub;


@end
