//
//  SampleTableViewCell.h
//  
//
//  Created by luck-mac on 15/8/19.
//
//

#import <UIKit/UIKit.h>

@interface SampleTableViewCell : UITableViewCell

@end
