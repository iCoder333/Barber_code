//
//  BarberModel.m
//  Barber
//
//  Created by Vadim Marina on 8/20/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "BarberModel.h"

@implementation BarberModel

@end
