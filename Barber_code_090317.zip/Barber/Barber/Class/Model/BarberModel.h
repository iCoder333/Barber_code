//
//  BarberModel.h
//  Barber
//
//  Created by Vadim Marina on 8/20/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Parse.h>

@interface BarberModel : NSObject

@property (nonatomic, strong) PFFile   *barberThumbImg;
@property (nonatomic, strong) NSString *barberUserImg;
@property (nonatomic, strong) NSString *rate;
@property (nonatomic, strong) NSString *price;
@property (nonatomic, strong) NSString *barberAddress;
@property (nonatomic, strong) NSString *reviewCount;
@property (nonatomic, strong) NSString *barberName;
@property (nonatomic, strong) NSString *titleName;

@end
