//
//  HomeViewController.m
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "HomeViewController.h"
#import "BarberTableViewCell.h"
#import "TPFloatRatingView.h"
#import "UIView+PullToBounce.h"
#import "LMPullToBounceWrapper.h"
#import "NSTimer+PullToBounce.h"
#import "BarberModel.h"
#import "HomeDetailViewController.h"
#import <UIImageView+WebCache.h>
#import "YiRefreshHeader.h"
#import <Parse.h>
#import "AppConstant.h"
#import "AppDelegate.h"
#import "SVProgressHUD.h"

#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;


@interface HomeViewController () <TPFloatRatingViewDelegate>
{
    YiRefreshHeader *refreshHeader;
    int total;

}

@property (weak,nonatomic) IBOutlet UITableView         *barberTableView;
@property (strong,nonatomic) NSArray                    *barberListArray;
@property (strong, nonatomic) NSMutableArray            *checkArray;
@property (nonatomic, strong) LMPullToBounceWrapper     *pushToBounceWrapper;
@property int selIndex;
@property (strong, nonatomic) PFObject                  *obj;
@property (strong, nonatomic) UIButton                  *btnLike;



@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _checkArray = [[NSMutableArray alloc] init];
    self.barberListArray = [[NSArray alloc] init];
    // Add Custom Loading Bar

    [self getData];
    
    // YiRefreshHeader  头部刷新按钮的使用
    refreshHeader=[[YiRefreshHeader alloc] init];
    refreshHeader.scrollView=self.barberTableView;
    [refreshHeader header];
    typeof(refreshHeader) __weak weakRefreshHeader = refreshHeader;
    refreshHeader.beginRefreshingBlock=^(){
        // 后台执行：
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            sleep(2);
            dispatch_async(dispatch_get_main_queue(), ^{
                typeof(weakRefreshHeader) __strong strongRefreshHeader = weakRefreshHeader;
                // 主线程刷新视图
                total=16;
                [self getData];
                [strongRefreshHeader endRefreshing];
            });
        });
    };

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(filterNotification) name:@"filterNotification" object:nil];
    // Do any additional setup after loading the view.
}

- (void)filterNotification
{
    [self getData];
}


#pragma mark - Get Data

- (void)getData
{
    [SVProgressHUD show];
    PFQuery *queryPass = [PFQuery queryWithClassName:@"BarberShop"];
    [queryPass orderByDescending:@"updatedAt"];
    [queryPass includeKey:@"baber"];
    if ([[AppDelegate sharedAllDelegate].strFlag isEqualToString:@"1"]) {
    }
    else if ([[AppDelegate sharedAllDelegate].strFlag isEqualToString:@"2"])
    {
        [queryPass whereKey:@"likeStatus" equalTo:@"1"];
    }

    [queryPass findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (error == nil) {
            [SVProgressHUD dismiss];
            
            self.barberListArray = objects;
            [self.barberTableView reloadData];
        }
        if (objects.count == 0) {
            [SVProgressHUD dismiss];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Barber Notice!" message:@"No Search Result!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
            
        }
        
    }];

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberofSectionInTableView:(UITableView*)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.barberListArray.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"BarberTableViewCell";
    BarberTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil)
        cell = [[BarberTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    
    
    self.obj = [self.barberListArray objectAtIndex:indexPath.row];
    
    
    PFFile *userFile = self.obj[@"brandImage"];
    [cell.barberImage sd_setImageWithURL:[NSURL URLWithString:userFile.url] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        
    } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
        
    }];
    
    PFUser *posterUser = self.obj[@"baber"];
    PFFile *profileImg = posterUser[PF_USER_PICTURE];
    
    if (posterUser == nil) {
        cell.userImage.image = [UIImage imageNamed:@"demoUser.png"];
    }
    else
    {
        [cell.userImage sd_setImageWithURL:[NSURL URLWithString:profileImg.url] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
            
        } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
            
        }];
    }
    
    
    
    cell.barberName.text = self.obj[@"barberName"];
    cell.barberRating.delegate = self;
    cell.barberRating.emptySelectedImage = [UIImage imageNamed:@"unsel_Star"];
    cell.barberRating.fullSelectedImage = [UIImage imageNamed:@"sel_Star"];
    cell.barberRating.contentMode = UIViewContentModeScaleAspectFill;
    cell.barberRating.maxRating = 5;
    cell.barberRating.minRating = 1;
    NSString *str = self.obj[@"rate"];;
    cell.barberRating.rating = (CGFloat)[str floatValue];
    cell.barberRating.editable = NO;
    cell.barberRating.halfRatings = NO;
    cell.barberRating.floatRatings = YES;
    
    cell.price.text = [NSString stringWithFormat:@"$%@",self.obj[@"price"]];
    cell.reivewCount.text = [NSString stringWithFormat:@"%@ Reviews",self.obj[@"reviewCount"]];
    cell.barberAddress.text = self.obj[@"barberAddress"];
    
    cell.btnLike.tag = indexPath.row;

    
    NSMutableArray *likeArray = self.obj[@"like"];

    
    if(!likeArray)
        likeArray = [NSMutableArray array];
    
    else if ([likeArray containsObject:[PFUser currentUser].objectId]) {
        [cell.btnLike setBackgroundImage:[UIImage imageNamed:@"selHeart.png"] forState:UIControlStateNormal];
    }
    else{
        [cell.btnLike setBackgroundImage:[UIImage imageNamed:@"whiteHeart.png"] forState:UIControlStateNormal];
    }
    cell.likeStatus = [likeArray containsObject:[PFUser currentUser].objectId];

    [cell.btnLike addTarget:self action:@selector(checkBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    return  cell;
    
}

-(void)checkBtnClicked:(id)sender{

    if ([PFUser currentUser].objectId == nil)
    {
        UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UIViewController *one = [board instantiateViewControllerWithIdentifier:@"loginVC"];
        UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:one];
        nc.navigationBar.hidden = YES;
        [self.navigationController presentModalViewController:nc animated:YES];
        
    }
    else
    {
        _btnLike = (UIButton*)sender;
        NSLog(@"button tag == %ld",(long)_btnLike.tag);
        _selIndex = _btnLike.tag;
        BarberTableViewCell *cell = [self.barberTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:_selIndex inSection:0]];
        if (cell.likeStatus) {
            
            PFQuery *query = [PFQuery queryWithClassName:@"BarberShop"];
            self.obj = [self.barberListArray objectAtIndex:_selIndex];
            
            [query whereKey:@"objectId" equalTo:self.obj.objectId];
            
            [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
                if (!error) {
                    PFObject *object = [objects firstObject];
                    NSMutableArray *array = [[NSMutableArray alloc] init];
                    array = [object objectForKey:@"like"];
                    [array removeObject:[PFUser currentUser].objectId];
                    object[@"like"] = array;
                    object[@"likeStatus"] = @"";
                    [object saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                        
                        if (error == nil) {
                            NSLog(@"UnLiked");
                            [_barberTableView reloadData];
                        }
                        
                    }];
                }
            }];
            
            
            
        }
        else
        {
            PFQuery *query = [PFQuery queryWithClassName:@"BarberShop"];
            self.obj = [self.barberListArray objectAtIndex:_selIndex];
            [query whereKey:@"objectId" equalTo:self.obj.objectId];
            
            [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
                if (!error) {
                    PFObject *object = [objects firstObject];
                    
                    NSMutableArray *array = [[NSMutableArray alloc] init];
                    array = [object objectForKey:@"like"];
                    if(!array)
                        array = [NSMutableArray array];
                    
                    [array addObject:[PFUser currentUser].objectId];
                    
                    object[@"like"] = array;
                    object[@"likeStatus"] = @"1";
                    [object saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                        
                        if (!error) {
                            NSLog(@"Liked");
                            [_barberTableView reloadData];
                        }
                        
                    }];
                }
            }];
        }
 
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    _selIndex = indexPath.row;
    
    self.obj = [self.barberListArray objectAtIndex:indexPath.row];
    
    HomeDetailViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"expDetailVC"];
    vc.selData = self.obj;
    [self.navigationController pushViewController:vc animated:YES];
}



- (IBAction)btnMenu:(id)sender
{
    [[SlideNavigationController sharedInstance] openMenu:MenuLeft withCompletion:nil];
}


- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
