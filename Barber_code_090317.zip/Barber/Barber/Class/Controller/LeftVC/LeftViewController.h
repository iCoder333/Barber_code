//
//  LeftViewController.h
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideNavigationController.h"

@interface LeftViewController : UIViewController <SlideNavigationControllerDelegate>

@property (nonatomic, assign) BOOL slideOutAnimationEnabled;


@end
