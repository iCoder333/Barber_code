//
//  HomeTableViewCell.h
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTableViewCell : UITableViewCell

@property (weak,nonatomic) IBOutlet UILabel             *titleLbl;
@property (weak,nonatomic) IBOutlet UIImageView         *hightImg;

@end
