//
//  LeftViewController.m
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "LeftViewController.h"
#import "HomeTableViewCell.h"
#import "NearTableViewCell.h"
#import "ScheduleTableViewCell.h"
#import "PaymentTableViewCell.h"
#import "SettingTableViewCell.h"
#import "FavTableViewCell.h"
#import "NotiTableViewCell.h"
#import "SettingTableViewCell.h"
#import <Parse.h>
#import "AppDelegate.h"
#import "AppConstant.h"

@interface LeftViewController () <UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) IBOutlet UITableView           *leftTableView;
@property (nonatomic,strong) IBOutlet UIImageView           *userProfileImg;
@property (nonatomic,strong) IBOutlet UILabel               *userName;
@property (nonatomic,strong) IBOutlet UILabel               *userEmail;

@end

@implementation LeftViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.userProfileImg.layer.cornerRadius = self.userProfileImg.frame.size.height / 2;
    self.userProfileImg.layer.masksToBounds = YES;
    self.userProfileImg.layer.borderWidth = 2.0f;
    self.userProfileImg.layer.backgroundColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1].CGColor;
    
    

    [self loadInitialProfile];
    
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    PFUser *user = [PFUser currentUser];
    if (user!=nil) {
        [self loadInitialProfile];
    }
    else
    {
        self.userName.text = @"Unknown";
        self.userEmail.text = @"Unknown";
    }
}


- (void)loadInitialProfile
{
    PFFile *profileImg = [PFUser currentUser][PF_USER_PICTURE];
    [profileImg getDataInBackgroundWithBlock:^(NSData *imageData, NSError *error) {
        UIImage *thumbnailImg = [UIImage imageWithData:imageData];
        self.userProfileImg.image = thumbnailImg;
        
    }];
    self.userName.text = [[PFUser currentUser] valueForKey:PF_USER_FULLNAME];
    self.userEmail.text = [[PFUser currentUser] valueForKey:PF_USER_USERNAME];
}

- (IBAction)btnLogout:(id)sender
{
    [[[UIAlertView alloc] initWithTitle:@"Warning!" message:@"Are you sure to log out?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil] show];
}

- (void)alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1) {
        [PFUser logOut];
        //        [self.sidebarController.navigationController popViewControllerAnimated:YES];
        [[SlideNavigationController sharedInstance] popToRootViewControllerAnimated:YES];
    }
}
#pragma makr - Table View Data Source

- (NSInteger)numberofSectionInTableView:(UITableView*)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 7;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        
        static NSString *identifier = @"HomeTableViewCell";
        HomeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell == nil)
            cell = [[HomeTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        
        cell.titleLbl.text = @"Barbers";
        UIView *bgColorView = [[UIView alloc] init];
        cell.titleLbl.highlightedTextColor = [UIColor blackColor];
        bgColorView.backgroundColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1];
        cell.hightImg.highlightedImage = [UIImage imageNamed:@"homeImg_"];
        [cell setSelectedBackgroundView:bgColorView];
        
        return cell;
    }
    if (indexPath.row == 1) {
        static NSString *identifier = @"FavTableViewCell";
        FavTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell == nil)
            cell = [[FavTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        
        cell.titleLbl.text = @"Favorite";
        UIView *bgColorView = [[UIView alloc] init];
        cell.titleLbl.highlightedTextColor = [UIColor blackColor];
        bgColorView.backgroundColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1];

        cell.hightImg.highlightedImage = [UIImage imageNamed:@"normal_fav_"];
        [cell setSelectedBackgroundView:bgColorView];
        
        
        return cell;
    }
    if (indexPath.row == 2) {
        static NSString *identifier = @"NearTableViewCell";
        NearTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell == nil)
            cell = [[NearTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        
        cell.titleLbl.text = @"Nearby";
        UIView *bgColorView = [[UIView alloc] init];
        cell.titleLbl.highlightedTextColor = [UIColor blackColor];
        bgColorView.backgroundColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1];

        cell.hightImg.highlightedImage = [UIImage imageNamed:@"normal_Map_"];
        [cell setSelectedBackgroundView:bgColorView];
        
        return cell;
    }
    if (indexPath.row == 3) {
        static NSString *identifier = @"NotiTableViewCell";
        NotiTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell == nil)
            cell = [[NotiTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        
        cell.titleLbl.text = @"Notifications";
        UIView *bgColorView = [[UIView alloc] init];
        cell.titleLbl.highlightedTextColor = [UIColor blackColor];
        bgColorView.backgroundColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1];

        cell.hightImg.highlightedImage = [UIImage imageNamed:@"normal_noti_"];
        [cell setSelectedBackgroundView:bgColorView];
        
        return cell;
    }
    if (indexPath.row == 4) {
        static NSString *identifier = @"ScheduleTableViewCell";
        ScheduleTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell == nil)
            cell = [[ScheduleTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        
        cell.titleLbl.text = @"Schedule";
        UIView *bgColorView = [[UIView alloc] init];
        cell.titleLbl.highlightedTextColor = [UIColor blackColor];
        bgColorView.backgroundColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1];

        cell.hightImg.highlightedImage = [UIImage imageNamed:@"norman_calendar_"];
        [cell setSelectedBackgroundView:bgColorView];
        
        return cell;
    }
    if (indexPath.row == 5) {
        static NSString *identifier = @"PaymentTableViewCell";
        PaymentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell == nil)
            cell = [[PaymentTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        
        cell.titleLbl.text = @"Payment";
        UIView *bgColorView = [[UIView alloc] init];
        cell.titleLbl.highlightedTextColor = [UIColor whiteColor];
        bgColorView.backgroundColor = [[UIColor alloc] initWithRed:29.0f/255.0 green:161.0f/255.0 blue:243.0f/255.0 alpha:1];

        cell.hightImg.highlightedImage = [UIImage imageNamed:@"normal_payment_"];
        [cell setSelectedBackgroundView:bgColorView];
        
        return cell;
    }
    if (indexPath.row == 6) {
        static NSString *identifier = @"SettingTableViewCell";
        SettingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell == nil)
            cell = [[SettingTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
        
        cell.titleLbl.text = @"Settings";
        UIView *bgColorView = [[UIView alloc] init];
        cell.titleLbl.highlightedTextColor = [UIColor blackColor];
        bgColorView.backgroundColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1];

        cell.hightImg.highlightedImage = [UIImage imageNamed:@"normal_settings_"];
        [cell setSelectedBackgroundView:bgColorView];
        
        return cell;
    }
    
    return 0;
    
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    UIViewController *vc ;
    
    switch (indexPath.row) {
        case 0:
            [AppDelegate sharedAllDelegate].strFlag = @"1";
            [[NSNotificationCenter defaultCenter] postNotificationName:@"filterNotification" object:nil];

            vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"HomeViewController"];
            break;
        case 1:
            [AppDelegate sharedAllDelegate].strFlag = @"2";
            [[NSNotificationCenter defaultCenter] postNotificationName:@"filterNotification" object:nil];

            vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"HomeViewController"];
            break;
        case 2:
            vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"MapViewController"];
            break;
        case 3:
            vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"NotificationViewController"];
            break;
        case 4:
            vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"ScheduleViewController"];
            break;
        case 5:
            vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"PaymentViewController"];
            break;
        case 6:
            vc = [mainStoryboard instantiateViewControllerWithIdentifier: @"SettingViewController"];
            break;
        default:
            break;
    }
    [[SlideNavigationController sharedInstance] popToRootAndSwitchToViewController:vc
                                                             withSlideOutAnimation:self.slideOutAnimationEnabled
                                                                     andCompletion:nil];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
