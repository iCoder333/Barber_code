//
//  MapViewController.h
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideNavigationController.h"
#import "TPFloatRatingView.h"

@interface MapViewController : UIViewController <SlideNavigationControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource,TPFloatRatingViewDelegate>

- (IBAction)btnMenu:(id)sender;

@end
