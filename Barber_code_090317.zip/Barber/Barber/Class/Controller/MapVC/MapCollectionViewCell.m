//
//  MapCollectionViewCell.m
//  Barber
//
//  Created by Vadim Marina on 8/24/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "MapCollectionViewCell.h"

@implementation MapCollectionViewCell


@end
