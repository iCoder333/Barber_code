//
//  MapViewController.m
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "MapViewController.h"
#import "SVProgressHUD.h"
#import <Parse.h>
#import "AppConstant.h"
#import "UIImageView+WebCache.h"
#import <MapKit/MapKit.h>
#import "MyCustomAnnotation.h"
#import "MapCollectionViewCell.h"
#import "HomeDetailViewController.h"

#define METERS_PER_MILE 1609.344


@interface MapViewController ()

@property (strong, nonatomic) IBOutlet        MKMapView *mapView;
@property (strong, nonatomic) IBOutlet        UILabel   *titleLbl;
@property (strong, nonatomic) NSArray                   *totalArray;
@property (strong, nonatomic) PFObject                  *obj;
@property int selIndex;
@property (strong, nonatomic) UIButton                  *btnLike;
@property (weak,nonatomic) IBOutlet  UICollectionView   *mapTableView;

@end

@implementation MapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.totalArray = [[NSArray alloc] init];
    
    [self getData];
    [self zoomToLocation];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)getData
{
    self.totalArray = [[NSArray alloc] init];
    [SVProgressHUD show];
    PFQuery *queryPass = [PFQuery queryWithClassName:@"BarberShop"];
    [queryPass orderByDescending:@"updatedAt"];
    
    [queryPass findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (error == nil) {
            [SVProgressHUD dismiss];
            
            self.totalArray = objects;
            [self.mapView addAnnotations:[self createAnnotations]];
            [self.mapTableView reloadData];
            
        }
        if (objects.count == 0) {
            [SVProgressHUD dismiss];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Tawfeer Notice!" message:@"No Search Result!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
            
        }
        
    }];
    
}

- (void)zoomToLocation
{
    
    CLLocationCoordinate2D zoomLocation;
    zoomLocation.latitude = 34.116241;
    zoomLocation.longitude= -118.297141;
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(zoomLocation, 17.5*METERS_PER_MILE,17.5*METERS_PER_MILE);
    [self.mapView setRegion:viewRegion animated:YES];
    [self.mapView regionThatFits:viewRegion];
}

- (NSMutableArray *)createAnnotations
{
    
    NSMutableArray *annotations = [[NSMutableArray alloc] init];
    
    for (int i = 0; i <= 8; i++) {
        
        self.obj = [self.totalArray objectAtIndex:i];
        PFFile *brandFile = self.obj[@"brandImage"];
        
        NSString *title = self.obj[@"barberName"];
        NSString *subtitle = self.obj[@"barberAddress"];
        
        NSString *imgPath = brandFile.url;
        CLLocationCoordinate2D coord;
        PFGeoPoint *geoPoint = self.obj[@"location"];
        coord.latitude = geoPoint.latitude;
        coord.longitude = geoPoint.longitude;
        NSString *strFromInt = [NSString stringWithFormat:@"%d",i];
        MyCustomAnnotation *annotation1 = [[MyCustomAnnotation alloc] initWithTitle:title subtitle:subtitle AndCoordinate:coord:imgPath subIndex:strFromInt];
        [annotations addObject:annotation1];
    }
    NSLog(@"ano === %@",_totalArray);
    return annotations;
}
- (MKAnnotationView *)mapView:(MKMapView *)sender viewForAnnotation:(id < MKAnnotation >)annotation
{
    static NSString *reuseId = @"StandardPin";
    
    MKAnnotationView *aView = (MKAnnotationView *)[sender
                                                   dequeueReusableAnnotationViewWithIdentifier:reuseId];
    if (aView == nil)
    {
        aView = [[MKAnnotationView alloc] initWithAnnotation:annotation
                                             reuseIdentifier:reuseId];
        
        aView.canShowCallout = YES;
    }
    
    aView.annotation = annotation;
    [aView setImage:[UIImage imageNamed:@"ccc.png"]];
    aView.canShowCallout = YES;
    
    
    aView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    
    return aView;
}

-(void) mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    MyCustomAnnotation *pin = (MyCustomAnnotation *) [view annotation];
    
    NSString *imgPath = pin.imgPath;
    
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 70, view.frame.size.height)];
    [imgView sd_setImageWithURL:[NSURL URLWithString:imgPath]];
    view.leftCalloutAccessoryView =  imgView;
    
    
}

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control {
    MyCustomAnnotation *pin = (MyCustomAnnotation *) [view annotation];
    
    int value = [pin.selIndex intValue];
    self.obj = [self.totalArray objectAtIndex:value];
    NSLog(@"index ==== %@",self.obj);
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HomeDetailViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"expDetailVC"];
    vc.selData = self.obj;
    [self.navigationController pushViewController:vc animated:YES];

}


#pragma mark - CollectionView Delegate

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    
    return self.totalArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"MapCollectionViewCell";
    
    MapCollectionViewCell *cell = (MapCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    self.obj = [self.totalArray objectAtIndex:indexPath.row];
    
    
    PFFile *userFile = self.obj[@"brandImage"];
    [cell.barberImage sd_setImageWithURL:[NSURL URLWithString:userFile.url] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        
    } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
        
    }];
    
    cell.barberName.text = self.obj[@"barberName"];
    cell.barberRating.delegate = self;
    cell.barberRating.emptySelectedImage = [UIImage imageNamed:@"unsel_Star"];
    cell.barberRating.fullSelectedImage = [UIImage imageNamed:@"sel_Star"];
    cell.barberRating.contentMode = UIViewContentModeScaleAspectFill;
    cell.barberRating.maxRating = 5;
    cell.barberRating.minRating = 1;
    NSString *str = self.obj[@"rate"];;
    cell.barberRating.rating = (CGFloat)[str floatValue];
    cell.barberRating.editable = NO;
    cell.barberRating.halfRatings = NO;
    cell.barberRating.floatRatings = YES;
    
    cell.price.text = [NSString stringWithFormat:@"$%@",self.obj[@"price"]];
    cell.reivewCount.text = [NSString stringWithFormat:@"%@ Reviews",self.obj[@"reviewCount"]];
    cell.barberAddress.text = self.obj[@"barberAddress"];
    
    cell.btnLike.tag = indexPath.row;
    
    
    NSMutableArray *likeArray = self.obj[@"like"];
    
    
    if(!likeArray)
        likeArray = [NSMutableArray array];
    
    else if ([likeArray containsObject:[PFUser currentUser].objectId]) {
        [cell.btnLike setBackgroundImage:[UIImage imageNamed:@"selHeart.png"] forState:UIControlStateNormal];
    }
    else{
        [cell.btnLike setBackgroundImage:[UIImage imageNamed:@"whiteHeart.png"] forState:UIControlStateNormal];
    }
    cell.likeStatus = [likeArray containsObject:[PFUser currentUser].objectId];
    
    [cell.btnLike addTarget:self action:@selector(checkBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    
    return  cell;
}

-(void)checkBtnClicked:(id)sender{
    
    if ([PFUser currentUser].objectId == nil)
    {
        UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UIViewController *one = [board instantiateViewControllerWithIdentifier:@"loginVC"];
        UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:one];
        nc.navigationBar.hidden = YES;
        [self.navigationController presentModalViewController:nc animated:YES];

    }
    else
    {
        _btnLike = (UIButton*)sender;
        NSLog(@"button tag == %ld",(long)_btnLike.tag);
        _selIndex = _btnLike.tag;
        MapCollectionViewCell *cell = [self.mapTableView cellForItemAtIndexPath:[NSIndexPath indexPathForRow:_selIndex inSection:0]];
        if (cell.likeStatus) {
            
            PFQuery *query = [PFQuery queryWithClassName:@"BarberShop"];
            self.obj = [self.totalArray objectAtIndex:_selIndex];
            
            [query whereKey:@"objectId" equalTo:self.obj.objectId];
            
            [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
                if (!error) {
                    PFObject *object = [objects firstObject];
                    NSMutableArray *array = [[NSMutableArray alloc] init];
                    array = [object objectForKey:@"like"];
                    [array removeObject:[PFUser currentUser].objectId];
                    object[@"like"] = array;
                    object[@"likeStatus"] = @"";
                    [object saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                        
                        if (error == nil) {
                            NSLog(@"UnLiked");
                            [_mapTableView reloadData];
                        }
                        
                    }];
                }
            }];
            
            
            
        }
        else
        {
            PFQuery *query = [PFQuery queryWithClassName:@"BarberShop"];
            self.obj = [self.totalArray objectAtIndex:_selIndex];
            [query whereKey:@"objectId" equalTo:self.obj.objectId];
            
            [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
                if (!error) {
                    PFObject *object = [objects firstObject];
                    
                    NSMutableArray *array = [[NSMutableArray alloc] init];
                    array = [object objectForKey:@"like"];
                    if(!array)
                        array = [NSMutableArray array];
                    
                    [array addObject:[PFUser currentUser].objectId];
                    
                    object[@"like"] = array;
                    object[@"likeStatus"] = @"1";
                    [object saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                        
                        if (!error) {
                            NSLog(@"Liked");
                            [_mapTableView reloadData];
                        }
                        
                    }];
                }
            }];
        }

    }
    
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    _selIndex = indexPath.row;
    self.obj = [self.totalArray objectAtIndex:_selIndex];
    
    CLLocationCoordinate2D coord;
    PFGeoPoint *geoPoint = self.obj[@"location"];
    coord.latitude = geoPoint.latitude;
    coord.longitude = geoPoint.longitude;
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(coord, 3.5*METERS_PER_MILE,3.5*METERS_PER_MILE);
    [self.mapView setRegion:viewRegion animated:YES];
    [self.mapView regionThatFits:viewRegion];
    
    
}

- (IBAction)btnMenu:(id)sender
{
    [[SlideNavigationController sharedInstance] openMenu:MenuLeft withCompletion:nil];
}


- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
