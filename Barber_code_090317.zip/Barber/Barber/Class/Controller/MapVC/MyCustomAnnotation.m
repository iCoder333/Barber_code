//
//  MyCustomAnnotation.m
//  MapViewAnnotation
//
//  Created by Sakshi Jain on 12/03/15.
//
//

#import "MyCustomAnnotation.h"

@implementation MyCustomAnnotation

@synthesize coordinate=_coordinate;
@synthesize title=_title;
@synthesize subtitle = _subtitle;
@synthesize img = _img;
@synthesize imgPath = _imgPath;
@synthesize selIndex = _selIndex;

-(id) initWithTitle:(NSString *) title subtitle: (NSString *)subtitle AndCoordinate:(CLLocationCoordinate2D)coordinate : (NSString *)imgPath subIndex :(NSString*)selIndex
{
    self = [super init];
    _title = title;
    _subtitle = subtitle;
    _coordinate = coordinate;
    _imgPath = imgPath;
    _selIndex = selIndex;

    return self;
}

@end
