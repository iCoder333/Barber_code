//
//  ScheduleViewController.m
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "ScheduleViewController.h"
#import <JTCalendar/JTCalendar.h>
#import "SVProgressHUD.h"
#import "ScheTableViewCell.h"
#import <Parse.h>
#import <UIImageView+WebCache.h>


@interface ScheduleViewController ()
{
    NSMutableDictionary *_eventsByDate;
    NSDate *_dateSelected;
    NSMutableArray *_sortArray;
}

@property (strong,nonatomic) NSArray                    *scheduleArray;

@property (weak,nonatomic) IBOutlet UITableView         *scheduleTableView;

@end

@implementation ScheduleViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self getData];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(filterEventNotification) name:@"filterEventNotification" object:nil];
    
    _calendarManager = [JTCalendarManager new];
    _calendarManager.delegate = self;
    
    _calendarManager.settings.pageViewHaveWeekDaysView = NO;
    _calendarManager.settings.pageViewNumberOfWeeks = 0; // Automatic
    
    _weekDayView.manager = _calendarManager;
    [_weekDayView reload];
    
    // Generate random events sort by date using a dateformatter for the demonstration
//    [self createRandomEvents];
    
    [_calendarManager setMenuView:_calendarMenuView];
    [_calendarManager setContentView:_calendarContentView];
    [_calendarManager setDate:[NSDate date]];
    
    _calendarMenuView.scrollView.scrollEnabled = NO; // Scroll not supported with JTVerticalCalendarView
}

- (void)filterEventNotification
{
    
    NSLog(@"NOTIFICATION CALLING");
    [self getSchedule1];
    [self.scheduleTableView reloadData];
    
}

- (void)getData
{
    self.scheduleArray = [[NSArray alloc] init];
    
    [SVProgressHUD show];
    
    PFQuery *queryPass = [PFQuery queryWithClassName:@"Book"];
    [queryPass orderByDescending:@"updatedAt"];
    [queryPass includeKey:@"customer"];
    [queryPass whereKey:@"customer" equalTo:[PFUser currentUser]];
    
    [queryPass findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
        if (error == nil) {
            
            [SVProgressHUD dismiss];
            self.scheduleArray = objects;
            [self getSchedule];
            
            [self.scheduleTableView reloadData];
            
            
        }
        if (objects.count == 0) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Barber Says!" message:@"No Search Schedules!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
            
        }
        
    }];

}

- (void)getSchedule
{
    _eventsByDate = [NSMutableDictionary new];
    _sortArray = [[NSMutableArray alloc] init];
    
    for(int i = 0; i < self.scheduleArray.count; ++i){
        // Generate 30 random dates between now and 60 days later
        
        PFObject *cu_obj = [self.scheduleArray objectAtIndex:i];
        NSCalendar *gregorian = [NSCalendar currentCalendar];
        
    
        NSString* eventDate = cu_obj[@"reminder"];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setDateFormat:@"dd-MM-yyyy"];
        NSDate *randomDate = [dateFormat dateFromString:eventDate];
        
        NSLog(@"Schedule Date ------- %@",randomDate);
        
        NSDateComponents *dateComponents = [gregorian components:(NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear) fromDate:randomDate];
        NSInteger month = [dateComponents month];
        NSInteger c_month = [[NSUserDefaults standardUserDefaults] integerForKey:@"currentMonth"];
        
        if (c_month == month) {
            [_sortArray addObject:cu_obj];
            NSLog(@"SORT ARRAY COUNT ===== %lu",(unsigned long)_sortArray.count);
        }
        
        
        // Use the date as key for eventsByDate
        NSString *key = [[self dateFormatter] stringFromDate:randomDate];
        
        if (key == nil) {
            
        }
        else
        {
            if(!_eventsByDate[key]){
                _eventsByDate[key] = [NSMutableArray new];
            }
            [_eventsByDate[key] addObject:randomDate];
        }
        
    }
    
    _calendarManager.delegate = self;
    [_calendarManager reload];
}

- (void)getSchedule1
{
    _eventsByDate = [NSMutableDictionary new];
    _sortArray = [[NSMutableArray alloc] init];
    
    for(int i = 0; i < self.scheduleArray.count; ++i){
        // Generate 30 random dates between now and 60 days later
        
        PFObject *cu_obj = [self.scheduleArray objectAtIndex:i];
        NSCalendar *gregorian = [NSCalendar currentCalendar];
        
        
        NSString* eventDate = cu_obj[@"reminder"];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setDateFormat:@"dd-MM-yyyy"];
        NSDate *randomDate = [dateFormat dateFromString:eventDate];
        
        NSLog(@"Schedule Date ------- %@",randomDate);
        
        NSDateComponents *dateComponents = [gregorian components:(NSCalendarUnitDay|NSCalendarUnitMonth|NSCalendarUnitYear) fromDate:randomDate];
        NSInteger month = [dateComponents month];
        NSInteger c_month = [[NSUserDefaults standardUserDefaults] integerForKey:@"currentMonth"];
        
        if (c_month == month) {
            [_sortArray addObject:cu_obj];
            NSLog(@"SORT ARRAY COUNT ===== %lu",(unsigned long)_sortArray.count);
        }
        
        
        // Use the date as key for eventsByDate
        NSString *key = [[self dateFormatter] stringFromDate:randomDate];
        
        if (key == nil) {
            
        }
        else
        {
            if(!_eventsByDate[key]){
                _eventsByDate[key] = [NSMutableArray new];
            }
            [_eventsByDate[key] addObject:randomDate];
        }
        
    }

}

#pragma makr - Table View Data Source

- (NSInteger)numberofSectionInTableView:(UITableView*)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return _sortArray.count;
    
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"ScheTableViewCell";
    ScheTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil)
        cell = [[ScheTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    
    PFObject *obj = [_sortArray objectAtIndex:indexPath.row];
    
    
    PFFile *imgFile = obj[@"barderImg"];
    [cell.barberImg sd_setImageWithURL:[NSURL URLWithString:imgFile.url] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        
    } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
        
    }];
    
    
    cell.barber_Name.text = obj[@"barderName"];
    cell.time_slot.text = obj[@"timeSlot"];
    cell.price.text = obj[@"price"];
    
    
    return  cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - CalendarManager delegate

// Exemple of implementation of prepareDayView method
// Used to customize the appearance of dayView
- (void)calendar:(JTCalendarManager *)calendar prepareDayView:(JTCalendarDayView *)dayView
{
    dayView.hidden = NO;
    
    // Hide if from another month
    if([dayView isFromAnotherMonth]){
        dayView.hidden = YES;
    }
    // Today
    else if([_calendarManager.dateHelper date:[NSDate date] isTheSameDayThan:dayView.date]){
        dayView.circleView.hidden = NO;
        dayView.circleView.backgroundColor = [UIColor redColor];
        dayView.dotView.backgroundColor = [UIColor whiteColor];
        dayView.textLabel.textColor = [UIColor whiteColor];
    }
    // Selected date
    else if(_dateSelected && [_calendarManager.dateHelper date:_dateSelected isTheSameDayThan:dayView.date]){
        dayView.circleView.hidden = NO;
        dayView.circleView.backgroundColor = [UIColor yellowColor];
        dayView.dotView.backgroundColor = [UIColor whiteColor];
        dayView.textLabel.textColor = [UIColor blackColor];
    }
    // Other month
    else if(![_calendarManager.dateHelper date:_calendarContentView.date isTheSameMonthThan:dayView.date]){
        dayView.circleView.hidden = YES;
        dayView.dotView.backgroundColor = [UIColor redColor];
        dayView.textLabel.textColor = [UIColor lightGrayColor];
    }
    // Another day of the current month
    else{
        dayView.circleView.hidden = YES;
        dayView.dotView.backgroundColor = [UIColor redColor];
        dayView.textLabel.textColor = [UIColor whiteColor];
    }
    
    if([self haveEventForDay:dayView.date]){
        dayView.dotView.hidden = NO;
        dayView.circleView.hidden = NO;
        dayView.circleView.backgroundColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1];
        dayView.dotView.backgroundColor = [UIColor blackColor];
        dayView.textLabel.textColor = [UIColor blackColor];
    }
    else{
        dayView.dotView.hidden = YES;
    }
}

- (void)calendar:(JTCalendarManager *)calendar didTouchDayView:(JTCalendarDayView *)dayView
{
    _dateSelected = dayView.date;
    
    // Animation for the circleView
    dayView.circleView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.1, 0.1);
    [UIView transitionWithView:dayView
                      duration:.3
                       options:0
                    animations:^{
                        dayView.circleView.transform = CGAffineTransformIdentity;
                        [_calendarManager reload];
                    } completion:nil];
    
    
    // Don't change page in week mode because block the selection of days in first and last weeks of the month
    if(_calendarManager.settings.weekModeEnabled){
        return;
    }
    
    // Load the previous or next page if touch a day from another month
    
    if(![_calendarManager.dateHelper date:_calendarContentView.date isTheSameMonthThan:dayView.date]){
        if([_calendarContentView.date compare:dayView.date] == NSOrderedAscending){
            [_calendarContentView loadNextPageWithAnimation];
        }
        else{
            [_calendarContentView loadPreviousPageWithAnimation];
        }
    }
}



#pragma mark - Fake data

// Used only to have a key for _eventsByDate
- (NSDateFormatter *)dateFormatter
{
    static NSDateFormatter *dateFormatter;
    if(!dateFormatter){
        dateFormatter = [NSDateFormatter new];
        dateFormatter.dateFormat = @"dd-MM-yyyy";
    }
    
    return dateFormatter;
}

- (BOOL)haveEventForDay:(NSDate *)date
{
    NSString *key = [[self dateFormatter] stringFromDate:date];
    
    if(_eventsByDate[key] && [_eventsByDate[key] count] > 0){
        return YES;
    }
    
    return NO;
    
}

- (void)createRandomEvents
{
    _eventsByDate = [NSMutableDictionary new];
    
    for(int i = 0; i < 30; ++i){
        // Generate 30 random dates between now and 60 days later
        NSDate *randomDate = [NSDate dateWithTimeInterval:(rand() % (3600 * 24 * 60)) sinceDate:[NSDate date]];
        
        // Use the date as key for eventsByDate
        NSString *key = [[self dateFormatter] stringFromDate:randomDate];
        
        if(!_eventsByDate[key]){
            _eventsByDate[key] = [NSMutableArray new];
        }
        
        [_eventsByDate[key] addObject:randomDate];
    }
}

- (IBAction)btnMenu:(id)sender
{
    [[SlideNavigationController sharedInstance] openMenu:MenuLeft withCompletion:nil];
}


- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}

#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        PFObject *dic = [_sortArray objectAtIndex:indexPath.row];
        
        // Log to Console
        NSLog(@"%@", dic.objectId);
        
        
        
        PFQuery *query = [PFQuery queryWithClassName:@"Book"];
        [query whereKey:@"objectId" equalTo:dic.objectId];
        [query whereKey:@"customer" equalTo:[PFUser currentUser]];
        
        [query findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error) {
            if (!error) {
                PFObject *object = [objects firstObject];
                
                [object deleteInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                    
                    if (error == nil) {
                        [_sortArray removeObjectAtIndex:indexPath.row];
                        
                        [self.scheduleTableView reloadData];
                        [self getData];
                        
                    }
                    
                }];
            }
        }];
        
        
        
        
    }
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
