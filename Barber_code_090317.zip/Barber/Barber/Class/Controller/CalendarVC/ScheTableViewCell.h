//
//  ScheTableViewCell.h
//  Barber
//
//  Created by Alex Buga on 8/29/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScheTableViewCell : UITableViewCell

@property (weak,nonatomic) IBOutlet UIImageView     *barberImg;
@property (weak,nonatomic) IBOutlet UILabel         *barber_Name;
@property (weak,nonatomic) IBOutlet UILabel         *time_slot;
@property (weak,nonatomic) IBOutlet UILabel         *price;

@end
