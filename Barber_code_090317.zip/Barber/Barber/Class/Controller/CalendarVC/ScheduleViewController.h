//
//  ScheduleViewController.h
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlideNavigationController.h"
#import <JTCalendar/JTCalendar.h>

@interface ScheduleViewController : UIViewController <SlideNavigationControllerDelegate,JTCalendarDelegate>


@property (weak, nonatomic) IBOutlet JTCalendarMenuView *calendarMenuView;
@property (weak, nonatomic) IBOutlet JTCalendarWeekDayView *weekDayView;
@property (weak, nonatomic) IBOutlet JTVerticalCalendarView *calendarContentView;

@property (strong, nonatomic) JTCalendarManager *calendarManager;


- (IBAction)btnMenu:(id)sender;

@end
