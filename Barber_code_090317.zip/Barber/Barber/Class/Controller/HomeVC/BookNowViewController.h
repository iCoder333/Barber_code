//
//  BookNowViewController.h
//  Barber
//
//  Created by Alex Buga on 8/28/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <JTCalendar/JTCalendar.h>
#import <Parse.h>

@interface BookNowViewController : UIViewController <JTCalendarDelegate>


@property (weak, nonatomic) IBOutlet JTCalendarMenuView *calendarMenuView;
@property (weak, nonatomic) IBOutlet JTCalendarWeekDayView *weekDayView;
@property (weak, nonatomic) IBOutlet JTVerticalCalendarView *calendarContentView;

@property (strong, nonatomic) JTCalendarManager *calendarManager;

@property (weak, nonatomic) NSString            *barber_Name;
@property (weak, nonatomic) NSString            *barber_Time;
@property (weak, nonatomic) NSString            *barber_Price;
@property (weak, nonatomic) PFFile              *brand_Image;



@end
