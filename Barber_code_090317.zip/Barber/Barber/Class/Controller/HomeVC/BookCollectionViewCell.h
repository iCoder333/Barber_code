//
//  BookCollectionViewCell.h
//  Barber
//
//  Created by Alex Buga on 8/28/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookCollectionViewCell : UICollectionViewCell

@property (weak,nonatomic) IBOutlet UIButton         *timeName;

@end
