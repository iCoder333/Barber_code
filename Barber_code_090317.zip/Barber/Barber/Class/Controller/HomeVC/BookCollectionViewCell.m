//
//  BookCollectionViewCell.m
//  Barber
//
//  Created by Alex Buga on 8/28/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "BookCollectionViewCell.h"

@implementation BookCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
    self.timeName.layer.cornerRadius = 4;
    self.timeName.clipsToBounds = YES;
    
}

@end
