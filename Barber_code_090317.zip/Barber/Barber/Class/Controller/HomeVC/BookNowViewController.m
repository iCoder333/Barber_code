//
//  BookNowViewController.m
//  Barber
//
//  Created by Alex Buga on 8/28/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "BookNowViewController.h"
#import <JTCalendar/JTCalendar.h>
#import "BookCollectionViewCell.h"
#import <UIImageView+WebCache.h>
#import "SVProgressHUD.h"
#import <Parse.h>

@interface BookNowViewController () <UICollectionViewDelegate,UICollectionViewDataSource>
{
    NSMutableDictionary *_eventsByDate;
    NSDate *_dateSelected;
    BOOL rememberPassword;
}

@property (weak,nonatomic) IBOutlet UICollectionView            *timeSlotCollection;
@property (strong,nonatomic) NSMutableArray                     *timeSlotArray;

@property (weak,nonatomic) IBOutlet UILabel                     *barberName;
@property (weak,nonatomic) IBOutlet UILabel                     *barberTime;
@property (weak,nonatomic) IBOutlet UIImageView                 *brandImage;
@property (weak,nonatomic) IBOutlet UILabel                     *barberPrice;
@property int selIndex;
@property (strong, nonatomic) UIButton                          *btnLike;
@property (strong, nonatomic) IBOutlet UIButton                 *btnConfirm;
@property (strong, nonatomic) NSDate                            *reminderDate;

@end

@implementation BookNowViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    _barberName.text = self.barber_Name;
    _barberTime.text = self.barber_Time;
    _barberPrice.text = [NSString stringWithFormat:@"$%@",self.barber_Price];
    
    self.btnConfirm.layer.cornerRadius = 4;
    self.btnConfirm.clipsToBounds = YES;
    
    [self.brandImage sd_setImageWithURL:[NSURL URLWithString:self.brand_Image.url] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        
    } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
        
    }];
    
    self.timeSlotArray = [[NSMutableArray alloc] initWithObjects:@"10:00 AM",@"11:00 AM",@"11:30 AM",@"03:00 PM",@"04:00 PM",@"06:00 PM", nil];
    
    _calendarManager = [JTCalendarManager new];
    _calendarManager.delegate = self;
    
    _calendarManager.settings.pageViewHaveWeekDaysView = NO;
    _calendarManager.settings.pageViewNumberOfWeeks = 0; // Automatic
    
    _weekDayView.manager = _calendarManager;
    [_weekDayView reload];
    
    
    [_calendarManager setMenuView:_calendarMenuView];
    [_calendarManager setContentView:_calendarContentView];
    [_calendarManager setDate:[NSDate date]];
    
    _calendarMenuView.scrollView.scrollEnabled = NO; // Scroll not supported with JTVerticalCalendarView
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - CollectionView Delegate

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    
    return self.timeSlotArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"BookCollectionViewCell";
    
    BookCollectionViewCell *cell = (BookCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    cell.timeName.tag = indexPath.row;
    [cell.timeName setTitle:[self.timeSlotArray objectAtIndex:indexPath.row] forState:UIControlStateNormal];

    [cell.timeName addTarget:self action:@selector(btnBook:) forControlEvents:UIControlEventTouchUpInside];
    return  cell;
}

- (IBAction)btnBook:(id)sender
{
   _btnLike = (UIButton*)sender;
    NSLog(@"button Tag = =%ld",(long)_btnLike.tag);
    _selIndex = _btnLike.tag;
   BookCollectionViewCell *cell = [self.timeSlotCollection cellForItemAtIndexPath:[NSIndexPath indexPathForRow:_selIndex inSection:0]];
    rememberPassword = !rememberPassword;
    if (rememberPassword) {
        
        cell.timeName.backgroundColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1];

        
    }
    else
    {
        cell.timeName.backgroundColor = [UIColor whiteColor];

    }
}

- (IBAction)btnConfrim:(id)sender
{
    [SVProgressHUD show];
    PFObject *obj = [PFObject objectWithClassName:@"Book"];
    obj[@"barderName"] = self.barberName.text;
    obj[@"timeSlot"] = [self.timeSlotArray objectAtIndex:self.selIndex];
    obj[@"price"] = self.barberPrice.text;
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd-MM-yyyy"];
    NSString *randomDate = [dateFormat stringFromDate:self.reminderDate];
    obj[@"reminder"] = randomDate;


    NSData *data = UIImageJPEGRepresentation(self.brandImage.image, 0.5);
    PFFile *imageFile = [PFFile fileWithName:@"brandPhoto" data:data];
    obj[@"barderImg"] = imageFile;
    obj[@"customer"] = [PFUser currentUser];
    
    [obj saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error)
     {
         [SVProgressHUD dismiss];
         if (error != nil) [SVProgressHUD showSuccessWithStatus:@"Successfully Confirmed!"];
         [self dismissViewControllerAnimated:YES completion:nil];
     }];

}



#pragma mark - CalendarManager delegate

// Exemple of implementation of prepareDayView method
// Used to customize the appearance of dayView
- (void)calendar:(JTCalendarManager *)calendar prepareDayView:(JTCalendarDayView *)dayView
{
    dayView.hidden = NO;
    
    // Hide if from another month
    if([dayView isFromAnotherMonth]){
        dayView.hidden = YES;
    }
    // Today
    else if([_calendarManager.dateHelper date:[NSDate date] isTheSameDayThan:dayView.date]){
        dayView.circleView.hidden = NO;
        dayView.circleView.backgroundColor = [UIColor redColor];
        dayView.dotView.backgroundColor = [UIColor whiteColor];
        dayView.textLabel.textColor = [UIColor whiteColor];

    }
    // Selected date
    else if(_dateSelected && [_calendarManager.dateHelper date:_dateSelected isTheSameDayThan:dayView.date]){
        dayView.circleView.hidden = NO;
        dayView.circleView.backgroundColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1];
        dayView.dotView.backgroundColor = [UIColor whiteColor];
        dayView.textLabel.textColor = [UIColor blackColor];

    }
    // Other month
    else if(![_calendarManager.dateHelper date:_calendarContentView.date isTheSameMonthThan:dayView.date]){
        dayView.circleView.hidden = YES;
        dayView.dotView.backgroundColor = [UIColor redColor];
        dayView.textLabel.textColor = [UIColor lightGrayColor];

    }
    // Another day of the current month
    else{
        dayView.circleView.hidden = YES;
        dayView.dotView.backgroundColor = [UIColor redColor];
        dayView.textLabel.textColor = [UIColor whiteColor];

    }
    
    if([self haveEventForDay:dayView.date]){
        dayView.dotView.hidden = NO;
    }
    else{
        dayView.dotView.hidden = YES;
    }
}

- (void)calendar:(JTCalendarManager *)calendar didTouchDayView:(JTCalendarDayView *)dayView
{
    _dateSelected = dayView.date;
    
    // Animation for the circleView
    dayView.circleView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.1, 0.1);
    [UIView transitionWithView:dayView
                      duration:.3
                       options:0
                    animations:^{
                        dayView.circleView.transform = CGAffineTransformIdentity;
                        NSLog(@"date == %@",dayView.date);
                        self.reminderDate = dayView.date;
                        [_calendarManager reload];
                    } completion:nil];
    
    
    // Don't change page in week mode because block the selection of days in first and last weeks of the month
    if(_calendarManager.settings.weekModeEnabled){
        return;
    }
    
    // Load the previous or next page if touch a day from another month
    
    if(![_calendarManager.dateHelper date:_calendarContentView.date isTheSameMonthThan:dayView.date]){
        if([_calendarContentView.date compare:dayView.date] == NSOrderedAscending){
            [_calendarContentView loadNextPageWithAnimation];
        }
        else{
            [_calendarContentView loadPreviousPageWithAnimation];
        }
    }
}

#pragma mark - Fake data

// Used only to have a key for _eventsByDate
- (NSDateFormatter *)dateFormatter
{
    static NSDateFormatter *dateFormatter;
    if(!dateFormatter){
        dateFormatter = [NSDateFormatter new];
        dateFormatter.dateFormat = @"dd-MM-yyyy";
    }
    
    return dateFormatter;
}

- (BOOL)haveEventForDay:(NSDate *)date
{
    NSString *key = [[self dateFormatter] stringFromDate:date];
    
    if(_eventsByDate[key] && [_eventsByDate[key] count] > 0){
        return YES;
    }
    
    return NO;
    
}

- (void)createRandomEvents
{
    _eventsByDate = [NSMutableDictionary new];
    
    for(int i = 0; i < 30; ++i){
        // Generate 30 random dates between now and 60 days later
        NSDate *randomDate = [NSDate dateWithTimeInterval:(rand() % (3600 * 24 * 60)) sinceDate:[NSDate date]];
        
        // Use the date as key for eventsByDate
        NSString *key = [[self dateFormatter] stringFromDate:randomDate];
        
        if(!_eventsByDate[key]){
            _eventsByDate[key] = [NSMutableArray new];
        }
        
        [_eventsByDate[key] addObject:randomDate];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
