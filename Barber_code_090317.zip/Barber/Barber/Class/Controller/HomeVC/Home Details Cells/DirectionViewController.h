//
//  DirectionViewController.h
//  Kitch Delivery
//
//  Created by Martin Lidaks on 4/12/16.
//  Copyright © 2016 Robert Sandoz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
//#import "ActivityVC.h"

@interface DirectionViewController : UIViewController <MKMapViewDelegate>

@property (strong, nonatomic) MKMapItem *destination;
@property (weak, nonatomic) IBOutlet MKMapView *routeMap;
@property (nonatomic) MKCoordinateRegion startingRegion;

@end
