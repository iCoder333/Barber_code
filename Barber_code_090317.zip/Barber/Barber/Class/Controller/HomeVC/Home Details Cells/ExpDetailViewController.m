//
//  ExpDetailViewController.m
//  Kitch
//
//  Created by Martin Lidaks on 4/2/16.
//  Copyright © 2016 Robert Sandoz. All rights reserved.
//

#import "ExpDetailViewController.h"
#import "KMMovieDetailsCell.h"
#import "KMMovieDetailsDescriptionCell.h"
#import "KMMovieDetailsSimilarMoviesCell.h"
#import "_KMSimilarMoviesCollectionViewCell.h"
#import "KMMovieDetailsCommentsCell.h"
#import "KMMovieDetailsViewAllCommentsCell.h"
#import "KMComposeCommentCell.h"
//#import "FullMenuList.h"
//#import "MapViewController.h"
//#import "AddCartViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
//#import "VideoPlayViewController.h"
//#import <UIImageView+WebCache.h>
//#import <Parse/Parse.h>
//#import <ParseUI/ParseUI.h>
#import "TPFloatRatingView.h"
#import "HomeModel.h"
#import "MeViewController.h"
#import "AppDelegate.h"
#import "DirectionViewController.h"

@interface ExpDetailViewController () <TPFloatRatingViewDelegate ,MKMapViewDelegate>
{
    NSArray *fullMenuArray;
}

@property (weak, nonatomic) IBOutlet KMScrollingHeaderView* scrollingHeaderView;
@property (weak, nonatomic) IBOutlet UIView                 *navigationBarView;
@property (weak, nonatomic) IBOutlet UILabel                *shopTitle;
@property (strong, nonatomic)               NSMutableArray* itemArray;
@property (strong, nonatomic) NSArray                       *similarDataArray;
@property int curIndex;
@end

@implementation ExpDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _itemArray = [[NSMutableArray alloc] init];
    _similarDataArray= [[NSMutableArray alloc] init];
    [self loadData];
    [self setupNavbarButtons];
    [self setupDetailsPageView];



    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)loadData
{
    HomeModel *data1 = [HomeModel new];
    data1.thumbImg = @"bedroom0.jpg";
    data1.posterImg = @"user0.jpg";
    data1.rate = @"5.0";
    data1.price = @"30";
    data1.name = @"Amazing hotel room 6 week let in Putney";
    data1.reviewCount = @"59";
    data1.posterName = @"Olesya Bob";
    
    HomeModel *data2 = [HomeModel new];
    data2.thumbImg = @"bedroom1.jpg";
    data2.posterImg = @"user1.jpg";
    data2.rate = @"4.5";
    data2.price = @"45";
    data2.name = @"Great double room in Central London - Xmas / New Year";
    data2.reviewCount = @"13";
    data2.posterName = @"Stefania Marina";
    
    HomeModel *data3 = [HomeModel new];
    data3.thumbImg = @"bedroom2.jpg";
    data3.posterImg = @"user2.jpg";
    data3.rate = @"4.8";
    data3.price = @"31";
    data3.name = @"Bright and airy 2 bedroom flat near central London";
    data3.reviewCount = @"70";
    data3.posterName = @"Cesla Amarelle";
    
    HomeModel *data4 = [HomeModel new];
    data4.thumbImg = @"bedroom3.jpg";
    data4.posterImg = @"user3.jpg";
    data4.rate = @"3.9";
    data4.price = @"21";
    data4.name = @"Beautiful garden bedroom in house";
    data4.reviewCount = @"67";
    data4.posterName = @"Denis Obuz";
    
    HomeModel *data5 = [HomeModel new];
    data5.thumbImg = @"bedroom4.jpg";
    data5.posterImg = @"user4.jpg";
    data5.rate = @"4.8";
    data5.price = @"20";
    data5.name = @"Sunny cosy room in leafy North Lond";
    data5.reviewCount = @"62";
    data5.posterName = @"Samuel Noodlez";
    
    HomeModel *data6 = [HomeModel new];
    data6.thumbImg = @"bedroom5.jpg";
    data6.posterImg = @"user5.jpg";
    data6.rate = @"4.4";
    data6.price = @"50";
    data6.name = @"Lovely room with ensuite in smart central location";
    data6.reviewCount = @"36";
    data6.posterName = @"Doris Muller";
    
    HomeModel *data7 = [HomeModel new];
    data7.thumbImg = @"bedroom6.jpg";
    data7.posterImg = @"user6.jpg";
    data7.rate = @"4.77";
    data7.price = @"62";
    data7.name = @"Double Room in Fulham, London SW";
    data7.reviewCount = @"27";
    data7.posterName = @"Alex Capus";
    
    HomeModel *data8 = [HomeModel new];
    data8.thumbImg = @"bedroom7.jpg";
    data8.posterImg = @"user7.jpg";
    data8.rate = @"user3.jpg";
    data8.price = @"60";
    data8.name = @"No throw pillows are needed for this glorious bed";
    data8.reviewCount = @"19";
    data8.posterName = @"Nadine Tokar";
    
    HomeModel *data9 = [HomeModel new];
    data9.thumbImg = @"bedroom8.jpg";
    data9.posterImg = @"user8.jpg";
    data9.rate = @"4.39";
    data9.price = @"74";
    data9.name = @"A bed so good, you'll show it off to your friends";
    data9.reviewCount = @"22";
    data9.posterName = @"Anina Schar";
    
    HomeModel *data10 = [HomeModel new];
    data10.thumbImg = @"bedroom9.jpg";
    data10.posterImg = @"user9.jpg";
    data10.rate = @"4.68";
    data10.price = @"81";
    data10.name = @"The Presidential Suite at the Hotel Cala di Volpe in Porto Cervo";
    data10.reviewCount = @"48";
    data10.posterName = @"Martin Kuenzi";
    
    HomeModel *data11 = [HomeModel new];
    data11.thumbImg = @"bedroom10.jpg";
    data11.posterImg = @"user10.jpg";
    data11.rate = @"4.01";
    data11.price = @"93";
    data11.name = @"Shangri-La Suite at the Shangri-La Bosphorus in Istanbul";
    data11.reviewCount = @"71";
    data11.posterName = @"Blatter Andrea";
    
    HomeModel *data12 = [HomeModel new];
    data12.thumbImg = @"bedroom11.jpg";
    data12.posterImg = @"user11.jpg";
    data12.rate = @"4.81";
    data12.price = @"56";
    data12.name = @"The Presidential Suite at the Mandarin Oriental in Shanghai";
    data12.reviewCount = @"53";
    data12.posterName = @"Simon Horat";
    
    HomeModel *data13 = [HomeModel new];
    data13.thumbImg = @"bedroom12.jpg";
    data13.posterImg = @"user12.jpg";
    data13.rate = @"4.19";
    data13.price = @"16";
    data13.name = @"The Royal Suite at the Hôtel Plaza Athénée in Paris";
    data13.reviewCount = @"21";
    data13.posterName = @"Julian Marbach";
    
    HomeModel *data14 = [HomeModel new];
    data14.thumbImg = @"bedroom13.jpg";
    data14.posterImg = @"user13.jpg";
    data14.rate = @"4.29";
    data14.price = @"25";
    data14.name = @"The St. Regis Villa at St. Regis Mauritius";
    data14.reviewCount = @"61";
    data14.posterName = @"Pawel Silberring";
    
    HomeModel *data15 = [HomeModel new];
    data15.thumbImg = @"bedroom14.jpg";
    data15.posterImg = @"user14.jpg";
    data15.rate = @"4.43";
    data15.price = @"30";
    data15.name = @"The Royal Suite at St. Regis Saadiyat Island";
    data15.reviewCount = @"33";
    data15.posterName = @"Flavio Meyer";
    
    HomeModel *data16 = [HomeModel new];
    data16.thumbImg = @"bedroom15.jpg";
    data16.posterImg = @"user15.jpg";
    data16.rate = @"user3.jpg";
    data16.price = @"40";
    data16.name = @"The Royal Villa at the Grand Resort Lagonissi in Athens";
    data16.reviewCount = @"22";
    data16.posterName = @"Marina Vergine";
    
    HomeModel *data17 = [HomeModel new];
    data17.thumbImg = @"bedroom16.jpg";
    data17.posterImg = @"user16.jpg";
    data17.rate = @"4.78";
    data17.price = @"50";
    data17.name = @"The Penthouse Suite at the Grand Hyatt Cannes Hôtel Martinez";
    data17.reviewCount = @"20";
    data17.posterName = @"Flavio Meyer";
    
    HomeModel *data18 = [HomeModel new];
    data18.thumbImg = @"bedroom17.jpg";
    data18.posterImg = @"user17.jpg";
    data18.rate = @"4.91";
    data18.price = @"43";
    data18.name = @"The Ty Warner Penthouse at the Four Seasons in New York";
    data18.reviewCount = @"17";
    data18.posterName = @"Betty Konyo";
    
    _similarDataArray = [NSArray arrayWithObjects:data1, data2, data3,data4,data5,data6,data7,data8,data9,data10,data11,data12, data13,data14,data15,data16,data17,data18,nil];

}

- (void)viewWillAppear:(BOOL)animated
{
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    self.navigationController.interactivePopGestureRecognizer.delegate = nil;
    self.scrollingHeaderView.navbarView = self.navigationBarView;
    
    [super viewWillAppear:animated];
}

#pragma mark - Setup Methods

- (void)setupDetailsPageView
{
    self.scrollingHeaderView.tableView.dataSource = self;
    self.scrollingHeaderView.tableView.delegate = self;
    self.scrollingHeaderView.delegate = self;
    self.scrollingHeaderView.tableView.separatorColor = [UIColor clearColor];
    self.scrollingHeaderView.headerImageViewContentMode = UIViewContentModeScaleToFill;
    
    [self.scrollingHeaderView reloadScrollingHeader];
}


- (void)setupNavbarButtons
{
    UIButton *buttonBack = [UIButton buttonWithType:UIButtonTypeCustom];
    
    buttonBack.frame = CGRectMake(10, 31, 22, 22);
    [buttonBack setImage:[UIImage imageNamed:@"back_icon"] forState:UIControlStateNormal];
    [buttonBack addTarget:self action:@selector(popViewController:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:buttonBack];
    
    UIButton *shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    shareButton.frame = CGRectMake(370, 26, 30, 30);
    [shareButton setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    [shareButton addTarget:self action:@selector(ShareViewController:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:shareButton];

    
    self.shopTitle.text = _selData.name;
}

- (IBAction)popViewController:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)ShareViewController:(id)sender
{
    NSString *theMessage = _selData.name;
    NSArray *items = @[[UIImage imageNamed:_selData.thumbImg],theMessage];
    
    // build an activity view controller
    UIActivityViewController *controller = [[UIActivityViewController alloc]initWithActivityItems:items applicationActivities:nil];
    
    // exclude several items (for example, Facepuke and Shitter)
    NSArray *excluded = @[UIActivityTypePostToFacebook, UIActivityTypePostToTwitter];
    controller.excludedActivityTypes = excluded;
    
    // and present it
    [self presentActivityController:controller];

}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section==0)
    {
        return 4;
    }
    else{
        NSLog(@"cont == %lu",(unsigned long)_itemArray.count);
        return _itemArray.count;
        
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // A much nicer way to deal with this would be to extract this code to a factory class, that would take care of building the cells.
    UITableViewCell* cell = nil;
    
    if (indexPath.section == 0) {
        switch (indexPath.row)
        {
            case 0:
            {
                KMMovieDetailsCell *detailsCell = [tableView dequeueReusableCellWithIdentifier:@"KMMovieDetailsCell"];
                
                if(detailsCell == nil)
                    detailsCell = [KMMovieDetailsCell movieDetailsCell];

                [detailsCell.btnName setTitle:_selData.posterName forState:UIControlStateNormal];
                
                
                
                detailsCell.genresLabel.text = _selData.name;
                detailsCell.rate.text = [NSString stringWithFormat:@"%@ Reviews",_selData.reviewCount];

                detailsCell.ratingView.delegate = self;
                detailsCell.ratingView.emptySelectedImage = [UIImage imageNamed:@"unsel_Star"];
                detailsCell.ratingView.fullSelectedImage = [UIImage imageNamed:@"sel_Star"];
                detailsCell.ratingView.contentMode = UIViewContentModeScaleAspectFill;
                detailsCell.ratingView.maxRating = 5;
                detailsCell.ratingView.minRating = 1;
                NSString *str = _selData.rate;
                detailsCell.ratingView.rating = (CGFloat)[str floatValue];
                detailsCell.ratingView.editable = NO;
                detailsCell.ratingView.halfRatings = NO;
                detailsCell.ratingView.floatRatings = YES;
                
                detailsCell.price.text = [NSString stringWithFormat:@"$%@",_selData.price];
                
                detailsCell.posterImageView.image = [UIImage imageNamed:_selData.posterImg];
                
                [detailsCell.btnName addTarget:self action:@selector(btnGoMap:) forControlEvents:UIControlEventTouchUpInside];

                
                cell = detailsCell;
                
                break;
            }
            case 1:
            {
                KMMovieDetailsCommentsCell *mapCell = [tableView dequeueReusableCellWithIdentifier:@"KMMovieDetailsCommentsCell"];
                if(mapCell == nil)
                    mapCell = [KMMovieDetailsCommentsCell movieDetailsCommentsCell];
                
                mapCell.mapView.scrollEnabled = false;
                mapCell.mapView.userInteractionEnabled = false;
                
                [mapCell.btnDirection addTarget:self action:@selector(btnGoMap:) forControlEvents:UIControlEventTouchUpInside];
                
                cell = mapCell;
                
                break;


            }
            case 2:
            {
                KMMovieDetailsSimilarMoviesCell *contributionCell = [tableView dequeueReusableCellWithIdentifier:@"KMMovieDetailsSimilarMoviesCell"];
                
                if(contributionCell == nil)
                    contributionCell = [KMMovieDetailsSimilarMoviesCell movieDetailsSimilarMoviesCell];
                
                [contributionCell.viewAllSimilarMoviesButton addTarget:self action:@selector(viewAllSimilarMoviesButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
                
                cell = contributionCell;
                
                break;
            }
            case 3:
            {
                KMComposeCommentCell *com = [tableView dequeueReusableCellWithIdentifier:@"KMComposeCommentCell"];
                
                if(com == nil)
                    com = [KMComposeCommentCell composeCommentsCell];
                
                [com.btnActivity addTarget:self action:@selector(btnActivity:) forControlEvents:UIControlEventTouchUpInside];
                [com.btnBills addTarget:self action:@selector(btnBills:) forControlEvents:UIControlEventTouchUpInside];
                [com.btnContact addTarget:self action:@selector(btnContact:) forControlEvents:UIControlEventTouchUpInside];
                [com.btnFiles addTarget:self action:@selector(btnFiles:) forControlEvents:UIControlEventTouchUpInside];
                
                cell = com;
                
                break;
            }

            default:
            break;
                
        }

    }
    else
    {
        KMMovieDetailsCommentsCell *foodCell = [tableView dequeueReusableCellWithIdentifier:@"KMMovieDetailsCommentsCell"];
        
        if(foodCell == nil)
            foodCell = [KMMovieDetailsCommentsCell movieDetailsCommentsCell];
        
        cell = foodCell;

    }
    
    return cell;
}

- (void)presentActivityController:(UIActivityViewController *)controller {
    
    // for iPad: make the presentation a Popover
    controller.modalPresentationStyle = UIModalPresentationPopover;
    [self presentViewController:controller animated:YES completion:nil];
    
    UIPopoverPresentationController *popController = [controller popoverPresentationController];
    popController.permittedArrowDirections = UIPopoverArrowDirectionAny;
    popController.barButtonItem = self.navigationItem.leftBarButtonItem;
    
    // access the completion handler
    controller.completionWithItemsHandler = ^(NSString *activityType,
                                              BOOL completed,
                                              NSArray *returnedItems,
                                              NSError *error){
        // react to the completion
        if (completed) {
            
            // user shared an item
            NSLog(@"We used activity type%@", activityType);
            
        } else {
            
            // user cancelled
            NSLog(@"We didn't want to share anything after all.");
        }
        
        if (error) {
            NSLog(@"An Error occured: %@, %@", error.localizedDescription, error.localizedFailureReason);
        }
    };
}

- (IBAction)btnGoMap:(id)sender
{
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    KMMovieDetailsCommentsCell *cell = (KMMovieDetailsCommentsCell*)[[sender superview] superview];
    DirectionViewController *routeVC = (DirectionViewController*)[storyboard instantiateViewControllerWithIdentifier:@"DirectionViewController"];
    routeVC.destination = [cell.matchingItems objectAtIndex:0];
    routeVC.startingRegion = cell.mapView.region;
    [self.navigationController pushViewController:routeVC animated:YES];

}

- (IBAction)btnVideoPlay:(id)sender
{
//    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//    VideoPlayViewController *vc = [board instantiateViewControllerWithIdentifier:@"VideoPlayVC"];
//    [self presentViewController:vc animated:YES completion:nil];
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    if (indexPath.section == 1) {
        
        self.curIndex = (int)indexPath.row;

//        PFObject *obj = [_itemArray objectAtIndex:self.curIndex];
//        
//        UIStoryboard     *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//        AddCartViewController *vc = [board instantiateViewControllerWithIdentifier:@"addCartVC"];
//        vc.foodTitle = obj[@"posterName"];
//        vc.desString = obj[@"des"];
//        vc.imgPath = obj[@"foodImg"];
//        vc.priceString = obj[@"price"];
//        vc.strRestName = obj[@"posterName"];
//        [self presentViewController:vc animated:YES completion:nil];
        
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.contentView.backgroundColor = [UIColor clearColor];
    
    if ([cell isKindOfClass:[KMMovieDetailsSimilarMoviesCell class]])
    {
        KMMovieDetailsSimilarMoviesCell* similarMovieCell = (KMMovieDetailsSimilarMoviesCell*)cell;
        
        [similarMovieCell setCollectionViewDataSourceDelegate:self index:indexPath.row];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // A much nicer way to deal with this would be to extract this code to a factory class, that would return the cells' height.
    CGFloat height = 0;
    
    if (indexPath.section == 0) {
        switch (indexPath.row)
        {
            case 0:
            {
                height = 764;
                break;
            }
            case 1:
            {
                height = 273;
                break;
            }
            case 2:
            {
                if ([_similarDataArray count] == 0)
                {
                    height = 0;
                }
                else
                {
                    height = 250;
                }
                break;
            }
            case 3:
            {
                height = 173;
                break;
            }
        }

    }
    else
    {
        height = 250;
    }
    
    
    return height;
}

#pragma mark - Leave a Commnet

- (void)writeComment:(id)sender
{
    
}


#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section;
{
    return [_similarDataArray count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath;
{
    _KMSimilarMoviesCollectionViewCell* cell = (_KMSimilarMoviesCollectionViewCell*)[collectionView dequeueReusableCellWithReuseIdentifier:@"_KMSimilarMoviesCollectionViewCell" forIndexPath:indexPath];
    
//    PFObject *obj = [_itemArray objectAtIndex:indexPath.row];
//    
//    [cell.cellImageView sd_setImageWithURL:[NSURL URLWithString:obj[@"foodImg"]] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
//        
//        
//    } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
//        
//        
//    }];

    HomeModel *similarData = nil;
    similarData = [_similarDataArray objectAtIndex:indexPath.row];
    
    cell.cellImageView.image = [UIImage imageNamed:similarData.thumbImg];
    return cell;
}

#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath;
{
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    ExpDetailViewController *vc = (ExpDetailViewController*)[storyboard instantiateViewControllerWithIdentifier:@"expDetailVC"];
    
    
    
//    self.curIndex = (int)indexPath.row;
//    PFObject *obj = [_itemArray objectAtIndex:self.curIndex];
//    vc.obj = obj;
    
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - KMScrollingHeaderViewDelegate

- (void)detailsPage:(KMScrollingHeaderView *)detailsPageView headerImageView:(UIImageView *)imageView
{
//    [imageView sd_setImageWithURL:[NSURL URLWithString:_obj[@"foodImg"]] placeholderImage:nil options:SDWebImageCacheMemoryOnly | SDWebImageRefreshCached progress:^(NSInteger receivedSize, NSInteger expectedSize) {
//        
//        
//    } completed:^(UIImage* image, NSError* error, SDImageCacheType cacheType, NSURL *imageURL) {
//        
//        
//    }];
    
    imageView.image = [UIImage imageNamed:_selData.thumbImg];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
