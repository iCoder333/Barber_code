//
//  KMPhotoTimelineDetailsCell.h
//  TheMovieDB
//
//  Created by Kevin Mindeguia on 04/02/2014.
//  Copyright (c) 2014 iKode Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPFloatRatingView.h"

@interface KMMovieDetailsCell : UITableViewCell <TPFloatRatingViewDelegate>

/**
 *  The movie poster image view
 */
@property (weak, nonatomic) IBOutlet UIImageView *posterImageView;
@property (strong, nonatomic) IBOutlet TPFloatRatingView *ratingView;

/**
 *  The movie genre label
 */

@property (weak, nonatomic) IBOutlet UILabel *barberName;
@property (weak, nonatomic) IBOutlet UILabel *address;
@property (weak, nonatomic) IBOutlet UILabel *rate;
@property (weak, nonatomic) IBOutlet UILabel *price;

@property (weak, nonatomic) IBOutlet UILabel *genresLabel;

/**
 *  The watch trailer button
 */
@property (weak, nonatomic) IBOutlet UIButton *bookNow;

/**
 *  The bookmark action button
 */
@property (weak, nonatomic) IBOutlet UIButton *goMap;

/**
 *  Call this method to create and configure a `KMMovieDetailsCell`
 *
 *  @return `KMMovieDetailsCell` instance
 */
+ (KMMovieDetailsCell *)movieDetailsCell;

@end
