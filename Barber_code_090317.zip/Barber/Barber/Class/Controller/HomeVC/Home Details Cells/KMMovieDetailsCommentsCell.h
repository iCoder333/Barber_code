//
//  KMPhotoTimelineCommentsCell.h
//  TheMovieDB
//
//  Created by Kevin Mindeguia on 04/02/2014.
//  Copyright (c) 2014 iKode Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
@import MapKit;
#import "SVAnnotation.h"
#import "SVPulsingAnnotationView.h"

@interface KMMovieDetailsCommentsCell : UITableViewCell <MKMapViewDelegate>

/**
 *  The user name label
 */
@property (weak, nonatomic) IBOutlet UIButton           *btnDirection;
@property (weak,nonatomic) IBOutlet MKMapView           *mapView;
@property (strong, nonatomic) NSMutableArray            *matchingItems;

/**
 *  The comment label
 */
@property (weak, nonatomic) IBOutlet UILabel        *price;
@property (weak, nonatomic) NSString                *str_address;
@property (weak, nonatomic) IBOutlet UITextView     *des;

/**
 *  The user avatar image view
 */
@property (weak, nonatomic) IBOutlet UIImageView    *foodImg;

/**
 *  Call this method to create and configure a `KMMovieDetailsCommentsCell`
 *
 *  @return `KMMovieDetailsCommentsCell` instance
 */
+ (KMMovieDetailsCommentsCell *)movieDetailsCommentsCell;
- (void) performSearch : (NSString*)address;
@end
