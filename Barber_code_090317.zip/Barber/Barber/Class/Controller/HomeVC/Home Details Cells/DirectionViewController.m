//
//  DirectionViewController.m
//  Kitch Delivery
//
//  Created by Martin Lidaks on 4/12/16.
//  Copyright © 2016 Robert Sandoz. All rights reserved.
//

#import "DirectionViewController.h"
#import "DistanceCell.h"

@interface DirectionViewController () <UITableViewDataSource , UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView        *distanceTableView;

@property (strong, nonatomic) NSMutableArray *directions;
@property (nonatomic) MKCoordinateRegion adjustedRegion;
@property (nonatomic) BOOL destinationVisible;
@property (strong, nonatomic) NSString *transportType;
@property NSUInteger count;
@property (strong, nonatomic) NSMutableArray *totalCount;
@property (strong, nonatomic) IBOutlet  UIImageView     *transfer;

@end

@implementation DirectionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.totalCount = [[NSMutableArray alloc] init];
    
    NSLog(@"RouteViewDidLoad");
    
    self.title = @"Directions";
    
    self.directions = [[NSMutableArray alloc]init];
    self.routeMap.delegate = self;
    self.routeMap.showsUserLocation = YES;
    
    MKPointAnnotation *annotationPoint = [[MKPointAnnotation alloc] init];
    annotationPoint.coordinate = self.destination.placemark.location.coordinate;
    annotationPoint.title = self.destination.placemark.name;
    
    [self.routeMap addAnnotation:annotationPoint];
    
    [self.routeMap setRegion:self.startingRegion animated:YES];
    
//    [self showCalucate];
    [self getDirections];

    // Do any additional setup after loading the view.
}

- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)resizeRegionWithDestination:(MKMapItem *)destination userLocation:(MKUserLocation *)userLocation
{
    NSLog(@"need to resize");
    CLLocationCoordinate2D destinationCoordinate = destination.placemark.location.coordinate;
    CLLocationCoordinate2D userCoordinate = userLocation.location.coordinate;
    
    double scaleFactor = 2;
    CLLocationDegrees latitudeDelta = (userCoordinate.latitude - destinationCoordinate.latitude)*scaleFactor;
    CLLocationDegrees longitudeDelta = (userCoordinate.longitude - destinationCoordinate.longitude)*scaleFactor;
    
    if (latitudeDelta < 0) {
        latitudeDelta = latitudeDelta * -1;
    }
    if (longitudeDelta < 0) {
        longitudeDelta = longitudeDelta * -1;
    }
    
    MKCoordinateSpan span = MKCoordinateSpanMake(latitudeDelta, longitudeDelta);
    
    CLLocationDegrees averageLatitude = (userCoordinate.latitude + destinationCoordinate.latitude)/2;
    CLLocationDegrees averageLongitude = (userCoordinate.longitude + destinationCoordinate.longitude)/2;
    CLLocationCoordinate2D centerCoordinate = CLLocationCoordinate2DMake(averageLatitude, averageLongitude);
    
    MKCoordinateRegion region = MKCoordinateRegionMake(centerCoordinate, span);
    
    self.adjustedRegion = [self.routeMap regionThatFits:region];
    [self.routeMap setRegion:self.adjustedRegion animated:YES];
}

- (void)getDirections{
    MKDirectionsRequest *request = [[MKDirectionsRequest alloc] init];
    
    request.source = [MKMapItem mapItemForCurrentLocation];
    request.destination = self.destination;
    request.requestsAlternateRoutes = YES;
    request.transportType = MKDirectionsTransportTypeWalking;
    
    MKDirections *estimatedTimeOfArrival = [[MKDirections alloc] initWithRequest:request];
    
    [estimatedTimeOfArrival calculateETAWithCompletionHandler:^(MKETAResponse *response, NSError *error) {
        if (error) {
            NSLog(@"eta error %@", error.localizedDescription);
        } else {
            NSTimeInterval maximumWalkingTime = 15*60;
            if (response.expectedTravelTime > maximumWalkingTime) {
                request.transportType = MKDirectionsTransportTypeAny;
                self.transportType = @"Driving";
                self.transfer.image = [UIImage imageNamed:@"bikeImg"];
            }else {
                request.transportType = MKDirectionsTransportTypeWalking;
                self.transportType = @"Walking";
                self.transfer.image = [UIImage imageNamed:@"walkImg"];
            }
            
            self.navigationItem.title = [NSString stringWithFormat:@"%@ Directions", self.transportType];
            
            MKDirections *directions = [[MKDirections alloc] initWithRequest:request];
            
            [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse *response, NSError *error) {
                if (error) {
                    NSLog(@"directions error %@", error.localizedDescription);
                } else{
                    [self showRoute:response];
                    if (!self.destinationVisible && !(self.adjustedRegion.center.latitude == 0)) {
                        [self.routeMap setRegion:self.adjustedRegion animated:YES];
                    }
                }
            }];
        }
    }];
}


- (void)showRoute:(MKDirectionsResponse *)response
{
    NSLog(@"route count  == %lu",(unsigned long)response.routes.count);
    
    for (MKRoute *route in response.routes) {
        self.count = route.steps.count;
        [self.totalCount addObject:[NSNumber numberWithInteger:self.count]];
        [self.routeMap addOverlay:route.polyline level:MKOverlayLevelAboveRoads];
        [self.directions removeAllObjects];
        for (MKRouteStep *step in route.steps) {
            [self.directions addObject:[NSString stringWithFormat:@"%@ for %0.f Km.", step.instructions, step.distance ]];
            [self.distanceTableView reloadData];
//by            [self dismiss];
        }
    }
    
}

- (MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay
{
    MKPolylineRenderer *renderer = [[MKPolylineRenderer alloc] initWithOverlay:overlay];
    
    renderer.strokeColor = [[UIColor alloc] initWithRed:73.0f/255.0 green:199.0f/255.0 blue:232.0f/255.0 alpha:1];
    renderer.lineWidth = 5.0;
    
    return renderer;
}

- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    NSLog(@"mapView didUpdateUserLocation %@", userLocation.location);
    [self resizeRegionWithDestination:self.destination userLocation:userLocation];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [self.directions count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"DistanceCell";
    DistanceCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (cell == nil)
        cell = [[DistanceCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:identifier];
    cell.detailLabel.text = [self.directions objectAtIndex:indexPath.row];
    return  cell;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
