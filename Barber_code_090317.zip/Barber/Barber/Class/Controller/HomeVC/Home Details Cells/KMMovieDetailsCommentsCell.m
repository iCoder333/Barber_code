//
//  KMPhotoTimelineCommentsCell.m
//  TheMovieDB
//
//  Created by Kevin Mindeguia on 04/02/2014.
//  Copyright (c) 2014 iKode Ltd. All rights reserved.
//

#import "KMMovieDetailsCommentsCell.h"

@implementation KMMovieDetailsCommentsCell

#pragma mark - Cell Init Methods

+ (KMMovieDetailsCommentsCell *)movieDetailsCommentsCell
{
    KMMovieDetailsCommentsCell* cell = [[[NSBundle mainBundle] loadNibNamed:@"KMMovieDetailsCommentsCell" owner:self options:nil] objectAtIndex:0];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

#pragma mark - View Lifecycle

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.btnDirection.layer.borderColor = [[UIColor alloc] initWithRed:73.0f/255.0 green:199.0f/255.0 blue:232.0f/255.0 alpha:1].CGColor;
    self.btnDirection.layer.cornerRadius = 16.0f;
    
    _matchingItems = [[NSMutableArray alloc] init];
    self.foodImg.layer.cornerRadius = self.foodImg.frame.size.width/2;
    self.foodImg.layer.masksToBounds = YES;
    
    _mapView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    [self.mapView setDelegate:self];
    
    
    
}

- (void) performSearch : (NSString*)address {
    
    NSLog(@"addres === %@",address);
    MKLocalSearchRequest *request = [[MKLocalSearchRequest alloc] init];
    request.naturalLanguageQuery = address;
    request.region = self.mapView.region;
    
    self.matchingItems = [[NSMutableArray alloc] init];
    
    MKLocalSearch *search = [[MKLocalSearch alloc] initWithRequest:request];
    
    [search startWithCompletionHandler:^(MKLocalSearchResponse *response, NSError *error) {
        __block MKPointAnnotation *firstAnnotation;
        
        if (response.mapItems.count == 0) {
            NSLog(@"No Matches");
        }else
        {
            [response.mapItems enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                MKMapItem *item = obj;
                if (idx == 0) {
                    [self.matchingItems addObject:item];
                    
                    MKCoordinateRegion region = MKCoordinateRegionMake(item.placemark.coordinate, MKCoordinateSpanMake(0.1, 0.1));
                    [self.mapView setRegion:region animated:NO];
                    
                    SVAnnotation *annotation = [[SVAnnotation alloc] initWithCoordinate:item.placemark.coordinate];
                    annotation.title = item.name;
                    [self.mapView addAnnotation:annotation];
                    firstAnnotation = annotation;
                    
                }
            }];
        }
        
        [self.mapView selectAnnotation:firstAnnotation animated:YES];
    }];
    
}


- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation {
    if([annotation isKindOfClass:[SVAnnotation class]]) {
        static NSString *identifier = @"Post Location";
        SVPulsingAnnotationView *pulsingView = (SVPulsingAnnotationView *)[self.mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
        
        if(pulsingView == nil) {
            pulsingView = [[SVPulsingAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
            pulsingView.annotationColor = [[UIColor alloc] initWithRed:83.0f/255.0 green:252.0f/255.0 blue:255.0f/255.0 alpha:1];
            pulsingView.canShowCallout = YES;
        }
        
        return pulsingView;
    }
    
    return nil;
}


@end
