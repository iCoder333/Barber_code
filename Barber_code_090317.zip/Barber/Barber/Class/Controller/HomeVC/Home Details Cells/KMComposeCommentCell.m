//
//  KMComposeCommentCell.m
//  TheMovieDB
//
//  Created by Kevin Mindeguia on 04/02/2014.
//  Copyright (c) 2014 iKode Ltd. All rights reserved.
//

#import "KMComposeCommentCell.h"

@implementation KMComposeCommentCell

#pragma mark - Cell Init Methods

+ (KMComposeCommentCell *)composeCommentsCell
{
    KMComposeCommentCell* cell = [[[NSBundle mainBundle] loadNibNamed:@"KMComposeCommentCell" owner:self options:nil] objectAtIndex:0];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

#pragma mark - View Lifecycle

- (void)awakeFromNib
{
    self.btnContact.layer.borderColor = [[UIColor alloc] initWithRed:73.0f/255.0 green:199.0f/255.0 blue:232.0f/255.0 alpha:1].CGColor;
    self.btnContact.layer.cornerRadius = 16.0f;
    self.btnBills.layer.borderColor = [[UIColor alloc] initWithRed:73.0f/255.0 green:199.0f/255.0 blue:232.0f/255.0 alpha:1].CGColor;
    self.btnBills.layer.cornerRadius = 16.0f;
    self.btnActivity.layer.borderColor = [[UIColor alloc] initWithRed:73.0f/255.0 green:199.0f/255.0 blue:232.0f/255.0 alpha:1].CGColor;
    self.btnActivity.layer.cornerRadius = 16.0f;
    self.btnFiles.layer.borderColor = [[UIColor alloc] initWithRed:73.0f/255.0 green:199.0f/255.0 blue:232.0f/255.0 alpha:1].CGColor;
    self.btnFiles.layer.cornerRadius = 16.0f;
}

@end
