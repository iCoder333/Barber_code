//
//  ExpDetailViewController.h
//  Kitch
//
//  Created by Martin Lidaks on 4/2/16.
//  Copyright © 2016 Robert Sandoz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KMScrollingHeaderView.h"
#import "BarberModel.h"

@interface ExpDetailViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, UICollectionViewDataSource, UICollectionViewDelegate,KMScrollingHeaderViewDelegate>

@property (strong, nonatomic) NSString          *testImg;
@property (strong, nonatomic) NSString          *strShopTitle;
@property (strong, nonatomic) NSString          *location;
@property (strong, nonatomic) NSString          *latitude;
@property (strong, nonatomic) NSString          *longitude;
@property (strong, nonatomic) BarberModel         *selData;

@end
