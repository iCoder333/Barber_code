//
//  DistanceCell.m
//  Kitch Delivery
//
//  Created by Martin Lidaks on 4/12/16.
//  Copyright © 2016 Robert Sandoz. All rights reserved.
//

#import "DistanceCell.h"

@implementation DistanceCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
