//
//  KMPhotoTimelineDetailsCell.m
//  TheMovieDB
//
//  Created by Kevin Mindeguia on 04/02/2014.
//  Copyright (c) 2014 iKode Ltd. All rights reserved.
//

#import "KMMovieDetailsCell.h"


@implementation KMMovieDetailsCell

#pragma mark - Init Methods

+ (KMMovieDetailsCell *)movieDetailsCell
{
    KMMovieDetailsCell* cell = [[[NSBundle mainBundle] loadNibNamed:@"KMMovieDetailsCell" owner:self options:nil] objectAtIndex:0];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        // Initialization code
    }
    return self;
}

#pragma mark - View Lifecycle

- (void)awakeFromNib
{
    self.posterImageView.layer.cornerRadius = self.posterImageView.frame.size.width/2;
    self.posterImageView.layer.masksToBounds = YES;
    
    self.goMap.layer.borderColor = [[UIColor alloc] initWithRed:73.0f/255.0 green:199.0f/255.0 blue:232.0f/255.0 alpha:1].CGColor;
    self.goMap.layer.cornerRadius = 16.0f;
    
    self.bookNow.layer.borderColor = [[UIColor alloc] initWithRed:73.0f/255.0 green:199.0f/255.0 blue:232.0f/255.0 alpha:1].CGColor;
    self.bookNow.layer.cornerRadius = 16.0f;

}

@end
