//
//  KMComposeCommentCell.h
//  TheMovieDB
//
//  Created by Kevin Mindeguia on 04/02/2014.
//  Copyright (c) 2014 iKode Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KMComposeCommentCell : UITableViewCell

/**
 *  The compose comment action button.
 */
@property (weak, nonatomic) IBOutlet UIButton *btnContact;
@property (weak, nonatomic) IBOutlet UIButton *btnBills;
@property (weak, nonatomic) IBOutlet UIButton *btnFiles;
@property (weak, nonatomic) IBOutlet UIButton *btnActivity;

/**
 *  Call this method to create and configure a `KMComposeCommentCell`
 *
 *  @return `KMComposeCommentCell` instance
 */
+ (KMComposeCommentCell *)composeCommentsCell;

@end
