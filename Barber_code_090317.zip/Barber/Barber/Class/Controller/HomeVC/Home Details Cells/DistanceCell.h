//
//  DistanceCell.h
//  Kitch Delivery
//
//  Created by Martin Lidaks on 4/12/16.
//  Copyright © 2016 Robert Sandoz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DistanceCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel        *detailLabel;

@end
