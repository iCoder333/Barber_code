//
//  ConfirmViewController.m
//  Barber
//
//  Created by Vadim Marina on 8/20/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "ConfirmViewController.h"

@interface ConfirmViewController ()

@end

@implementation ConfirmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _verify_button.layer.cornerRadius = 22; // this value vary as per your desire
    _verify_button.clipsToBounds = YES;
    _loadHub.hidden = YES;
    
    // Do any additional setup after loading the view.
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSUInteger newLength = [_confirmCode.text length] + [string length] - range.length;
    return (newLength > 6) ? NO : YES;
}


- (IBAction)btnCreateAccount:(id)sender
{
    _loadHub.hidden = NO;
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:3.0f
                                                  target:self
                                                selector:@selector(_timerFired:)
                                                userInfo:nil
                                                 repeats:YES];
    }
    
}

- (void)_timerFired:(NSTimer *)timer {
    NSLog(@"ping");
    [_timer invalidate];
    _timer = nil;
    
    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController    *vc = [board instantiateViewControllerWithIdentifier:@"HomeViewController"];
    [self.navigationController pushViewController:vc animated:YES];
    
}

- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
