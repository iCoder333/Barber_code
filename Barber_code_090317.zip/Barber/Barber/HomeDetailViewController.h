//
//  HomeDetailViewController.h
//  Barber
//
//  Created by Vadim Marina on 8/20/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KMScrollingHeaderView.h"
#import "BarberModel.h"
#import <Parse.h>


@interface HomeDetailViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, UICollectionViewDataSource, UICollectionViewDelegate,KMScrollingHeaderViewDelegate>

@property (strong, nonatomic) NSString          *testImg;
@property (strong, nonatomic) NSString          *strShopTitle;
@property (strong, nonatomic) NSString          *location;
@property (strong, nonatomic) NSString          *latitude;
@property (strong, nonatomic) NSString          *longitude;
@property (strong, nonatomic) PFObject          *selData;

@end
