//
//  AppConstant.h
//  Scumper
//
//  Created by Stefania on 8/13/15.
//  Copyright (c) 2015 Stefania. All rights reserved.
//

#ifndef Scumper_AppConstant_h
#define Scumper_AppConstant_h

/*
#define IS_IPHONE_5_( fabs( ( double ) [ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 < DBL_EPSION )
#define IS_IPHONE_6_( fabs( ( double ) [ [ UIScreen mainScreen ] bounds ].size.height - ( double )667 < DBL_EPSION )
#define IS_IPHONE_6Plus_( fabs( ( double ) [ [ UIScreen mainScreen ] bounds ].size.height - ( double )736 < DBL_EPSION )*/


#define IS_OS_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
#define SLIDE_MENU_STYLE 2

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)
#define HEXCOLOR(c) [UIColor colorWithRed:((c>>24)&0xFF)/255.0 green:((c>>16)&0xFF)/255.0 blue:((c>>8)&0xFF)/255.0 alpha:((c)&0xFF)/255.0]

#define		FIREBASE							@"https://tinkle-app.firebaseio.com/"

//-------------------------------------------------------------------------------------------------------------------------------------------------
#define		DEFAULT_TAB							0

//-------------------------------------------------------------------------------------------------------------------------------------------------
#define		VIDEO_LENGTH						5

//-------------------------------------------------------------------------------------------------------------------------------------------------
#define		COLOR_OUTGOING						HEXCOLOR(0x007AFFFF)
#define		COLOR_INCOMING						HEXCOLOR(0xE6E5EAFF)

//-------------------------------------------------------------------------------------------------------------------------------------------------
#define		SCREEN_WIDTH						[UIScreen mainScreen].bounds.size.width
#define		SCREEN_HEIGHT						[UIScreen mainScreen].bounds.size.height

//-------------------------------------------------------------------------------------------------------------------------------------------------
#define		PREMIUM_LINK						@"http://www.relatedcode.com/premium"

//-------------------------------------------------------------------------------------------------------------------------------------------------
#define		MESSAGE_INVITE						@"Check out chatexamples.com"



#define  PARSE_APP_ID               @"rWdNEA13IUy9Kz6ogn2QgGyE8b5ekVYYMpV28Ahi"
#define  PARSE_CLIENT_KEY           @"9jNkJTrwtO09Zq81tUwlhM3QQnBXq7tEe2GY1CN0"

#define		PF_USER_CLASS_NAME					@"_User"				//	Class name
#define		PF_INSTALLATION_USER				@"user"	
#define		PF_USER_OBJECTID					@"objectId"
#define		PF_USER_USERNAME					@"username"				//	String
#define		PF_USER_PASSWORD					@"password"				//	String
#define		PF_USER_EMAIL						@"email"				//	String
#define		PF_USER_EMAILCOPY					@"emailCopy"			//	String
#define		PF_USER_FULLNAME                    @"fullname"				//	String
#define		PF_USER_POINT                       @"point"		
#define		PF_USER_FULLNAME_LOWER				@"fullname_lower"		//	String
#define		PF_USER_TWITTERID					@"twitterId"			//	String
#define		PF_USER_FACEBOOKID					@"facebookId"			//	String
#define		PF_USER_LOCATION					@"location"		
#define		PF_USER_TYPE                        @"userType"		
#define		PF_USER_ADDRESS					    @"address"	
#define		PF_USER_PICTURE						@"profileImage"				//	URL
#define		PF_USER_THUMBNAIL					@"thumbnail"
#define		PF_USER_PHONENUMBER					@"phoneNumber"
#define     PF_USER_CITY                        @"city"
#define     PF_USER_ACCOUNT_TYPE                @"userType"
#define     PF_USER_CAPTION                     @"caption"
#define     PF_USER_LIKES                       @"likes"
#define     PF_USER_DISLIKES                    @"dislikes"

//-- EVENT Class

#define     PF_EVENT_CLASS                      @"Event"
#define     PF_EVENT_IMG                        @"eventImg"
#define     PF_EVENT_NAME                       @"eventName"
#define     PF_EVENTY_DATE                      @"eventDate"
#define     PF_EVENTY_TIME                      @"eventTime"
#define     PF_EVENT_ADDRESS                    @"eventAddress"
#define     PF_EVENT_LOCATION                   @"location"
#define     PF_EVENT_WEBSITE                    @"website"
#define     PF_EVENT_SPACE                      @"space"
#define     PF_EVENT_CAPTION                    @"caption"
#define     PF_EVENT_PRICE                      @"price"
#define     PF_EVENT_TYPE                       @"eventType"
#define     PF_EVENT_POSTALCODE                 @"postalCode"
#define     PF_EVENT_POSTERUSER                 @"posterUser"





//-----------------------------------------------------------------------
#define		PF_BLOCKED_CLASS_NAME				@"Blocked"				//	Class name
#define		PF_BLOCKED_USER						@"user"					//	Pointer to User Class
#define		PF_BLOCKED_USER1					@"user1"				//	Pointer to User Class
#define		PF_BLOCKED_USER2					@"user2"				//	Pointer to User Class
#define		PF_BLOCKED_USERID2					@"userId2"				//	String
//-----------------------------------------------------------------------
#define		PF_GROUP_CLASS_NAME					@"Group"				//	Class name
#define		PF_GROUP_USER						@"user"					//	Pointer to User Class
#define		PF_GROUP_NAME						@"name"					//	String
#define		PF_GROUP_MEMBERS					@"members"				//	Array
//-----------------------------------------------------------------------
#define		PF_PEOPLE_CLASS_NAME				@"People"				//	Class name
#define		PF_PEOPLE_USER1						@"user1"				//	Pointer to User Class
#define		PF_PEOPLE_USER2						@"user2"				//	Pointer to User Class
//-----------------------------------------------------------------------
#define		PF_REPORT_CLASS_NAME				@"Report"				//	Class name
#define		PF_REPORT_USER1						@"user1"				//	Pointer to User Class
#define		PF_REPORT_USER2						@"user2"				//	Pointer to User Class
//------------------------------------------------------------------------------------------------

#define		NOTIFICATION_APP_STARTED			@"NCAppStarted"
#define		NOTIFICATION_USER_LOGGED_IN			@"NCUserLoggedIn"
#define		NOTIFICATION_USER_LOGGED_OUT		@"NCUserLoggedOut"


#endif
