//
//  ViewController.m
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "ViewController.h"
#import "SignUpViewController.h"
#import <Parse.h>
#import "AppConstant.h"
#import "SVProgressHUD.h"
#import "push.h"

@interface ViewController ()
{
    BOOL rememberPassword;
}

@property (weak,nonatomic) IBOutlet UITextField         *userNameTxt;
@property (weak,nonatomic) IBOutlet UITextField         *passwordTxt;
@property (weak,nonatomic) IBOutlet UIButton            *btnAppLogin;
@property (weak,nonatomic) IBOutlet UIButton            *btnAppSignUp;
@property (weak,nonatomic) IBOutlet UIButton            *btnForgotPwd;
@property (weak,nonatomic) IBOutlet UIButton            *btnFacebookLogin;
@property (weak,nonatomic) IBOutlet UIButton            *btnRememberPwd;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // TextField Placeholder Color
    NSAttributedString *userName = [[NSAttributedString alloc] initWithString:@"Your email" attributes:@{ NSForegroundColorAttributeName : [[UIColor alloc] initWithRed:255.0/255.0f green:255.0/255.0f blue:255.0/255.0f alpha:1]}];
    self.userNameTxt.attributedPlaceholder = userName;
    
    NSAttributedString *password = [[NSAttributedString alloc] initWithString:@"Password" attributes:@{ NSForegroundColorAttributeName : [[UIColor alloc] initWithRed:255.0/255.0f green:255.0/255.0f blue:255.0/255.0f alpha:1]}];
    self.passwordTxt.attributedPlaceholder = password;
    
    // Buttons Border Change
    self.btnAppLogin.layer.cornerRadius = 22;
    self.btnAppLogin.clipsToBounds = YES;
    self.btnFacebookLogin.layer.cornerRadius = 22;
    self.btnFacebookLogin.clipsToBounds = YES;
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

/*
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController    *vc = [board instantiateViewControllerWithIdentifier:@"HomeViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}
*/

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    PFUser *user = [PFUser currentUser];
    if (user!=nil) {
        UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UIViewController    *vc = [board instantiateViewControllerWithIdentifier:@"HomeViewController"];
        [self.navigationController pushViewController:vc animated:YES];
    }
}


- (IBAction)btnClose:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - RememberPassword

- (IBAction)btnRememberPwd:(id)sender;
{
    rememberPassword = !rememberPassword;
    if (rememberPassword) {
        
        [self.btnRememberPwd setBackgroundImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
        
    }
    else
    {
        [self.btnRememberPwd setBackgroundImage:[UIImage imageNamed:@"unCheck"] forState:UIControlStateNormal];
    }
    
}

#pragma mark - Login Action

- (IBAction)btnAppLogin:(id)sender
{
    if ([[self.userNameTxt text] length] == 0) {
        [[[UIAlertView alloc] initWithTitle:@"Barber Notice!" message:@"Please Input E-Mail" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
        [self.userNameTxt becomeFirstResponder];
        return;
    }
    else if ([[self.passwordTxt text] length] == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Barber Notice!" message:@"Please Input Password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
        [self.passwordTxt becomeFirstResponder];
        return;
    }
    else
    {
        {
            [SVProgressHUD showWithStatus:@"Logging..."];
            
            [PFUser logInWithUsernameInBackground:self.userNameTxt.text password:self.passwordTxt.text block:^(PFUser *user, NSError *error)
             {
                 ;  if (user)
                 {
                     [SVProgressHUD dismiss];
                     NSLog(@"Log in Success");
                     
                     [self dismissViewControllerAnimated:YES completion:nil];
                     
                     
                     
                 }
                 else
                 {
                     [SVProgressHUD dismiss];
                     [SVProgressHUD showErrorWithStatus:nil];
                     
                     [[[UIAlertView alloc] initWithTitle:@"Wannagodo Says" message:@"Don't match E-mail and Password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
                 }
             }];
        }
    }
}

#pragma mark - Facebook Login Action

- (IBAction)btnFacebookLogin:(id)sender
{
    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    UIViewController    *vc = [board instantiateViewControllerWithIdentifier:@"HomeViewController"];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - SignUp Action

- (IBAction)btnGoSignUp:(id)sender
{
    UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    SignUpViewController *vc = [board instantiateViewControllerWithIdentifier:@"signupVC"];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
