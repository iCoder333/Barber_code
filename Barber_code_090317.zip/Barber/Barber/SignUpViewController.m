//
//  SignUpViewController.m
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "SignUpViewController.h"
#import "SCLAlertView.h"
#import "DLRadioButton.h"
#import "AppDelegate.h"
#import "SVProgressHUD.h"
#import "push.h"
#import <Parse.h>
#import "AppConstant.h"


NSString *kSuccessTitle = @"Profile Picture";
NSString *kErrorTitle = @"Connection error";
NSString *kNoticeTitle = @"Notice";
NSString *kWarningTitle = @"Warning";
NSString *kInfoTitle = @"Profile Picture";
NSString *kSubtitle = @"Please Select Profile Photo from Camera or iPad Gallery";
NSString *kButtonTitle = @"Close";
NSString *kAttributeTitle = @"Attributed string operation successfully completed.";

@interface SignUpViewController () <UIImagePickerControllerDelegate, UINavigationControllerDelegate , UIActionSheetDelegate>

@property (weak,nonatomic) IBOutlet UIImageView             *userPhotoImg;
@property (weak,nonatomic) IBOutlet UIButton                *btnRegister;
@property (weak,nonatomic) IBOutlet UIButton                *btnFacebook;
@property (weak,nonatomic) IBOutlet UITextField             *userName;
@property (weak,nonatomic) IBOutlet UITextField             *userPhoneNumber;
@property (weak,nonatomic) IBOutlet UITextField             *userEmail;
@property (weak,nonatomic) IBOutlet UITextField             *userAddress;
@property (weak,nonatomic) IBOutlet UITextField             *password;
@property (weak, nonatomic) NSString                        *accountType;

@end

@implementation SignUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // TextField Placeholder Color
    NSAttributedString *userName = [[NSAttributedString alloc] initWithString:@"Username" attributes:@{ NSForegroundColorAttributeName : [[UIColor alloc] initWithRed:255.0/255.0f green:255.0/255.0f blue:255.0/255.0f alpha:1]}];
    self.userName.attributedPlaceholder = userName;
    
    NSAttributedString *password = [[NSAttributedString alloc] initWithString:@"Password" attributes:@{ NSForegroundColorAttributeName : [[UIColor alloc] initWithRed:255.0/255.0f green:255.0/255.0f blue:255.0/255.0f alpha:1]}];
    self.password.attributedPlaceholder = password;
    
    NSAttributedString *phoneNumber = [[NSAttributedString alloc] initWithString:@"Phone Number" attributes:@{ NSForegroundColorAttributeName : [[UIColor alloc] initWithRed:255.0/255.0f green:255.0/255.0f blue:255.0/255.0f alpha:1]}];
    self.userPhoneNumber.attributedPlaceholder = phoneNumber;
    
    NSAttributedString *userEmail = [[NSAttributedString alloc] initWithString:@"Your Email" attributes:@{ NSForegroundColorAttributeName : [[UIColor alloc] initWithRed:255.0/255.0f green:255.0/255.0f blue:255.0/255.0f alpha:1]}];
    self.userEmail.attributedPlaceholder = userEmail;
    
    // Buttons Border Change
    self.btnRegister.layer.cornerRadius = 22;
    self.btnRegister.clipsToBounds = YES;
    self.btnFacebook.layer.cornerRadius = 22;
    self.btnFacebook.clipsToBounds = YES;

    self.userAddress.text = [NSString stringWithFormat:@"%@,%@,%@",[AppDelegate sharedAllDelegate].strCity,[AppDelegate sharedAllDelegate].strRegion,[AppDelegate sharedAllDelegate].strCountry];

    self.userPhotoImg.layer.cornerRadius = self.userPhotoImg.frame.size.height / 2;
    self.userPhotoImg.layer.masksToBounds = YES;
    // Do any additional setup after loading the view.
}

#pragma mark - Add Profile Photo

- (IBAction)btnAddPhoto:(id)sender
{
    
    SCLAlertView *alert = [[SCLAlertView alloc] init];
    
    alert.shouldDismissOnTapOutside = YES;
    
    [alert addButton:@"Take Photo" actionBlock:^(void) {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker.allowsEditing = TRUE;
        [self presentModalViewController:picker animated:YES];
        
    }];
    [alert addButton:@"Choose From Library" actionBlock:^(void) {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        picker.allowsEditing = TRUE;
        [self presentModalViewController:picker animated:YES];
        
    }];
    
    [alert alertIsDismissed:^{
        NSLog(@"SCLAlertView dismissed!");
    }];
    
    [alert showInfo:self title:kInfoTitle subTitle:kSubtitle closeButtonTitle:kButtonTitle duration:0.0f];
    
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *selectedImg = info[UIImagePickerControllerEditedImage];
    self.userPhotoImg.image = selectedImg;
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Choose User Type (Salon or Baber)

- (IBAction)chooseUserType:(DLRadioButton *)radioButton {
    if (radioButton.isMultipleSelectionEnabled) {
        for (DLRadioButton *button in radioButton.selectedButtons) {
            NSLog(@"%@ is selected.\n", button.titleLabel.text);
            self.accountType = radioButton.selectedButton.titleLabel.text;
        }
    } else {
        NSLog(@"%@ is selected.\n", radioButton.selectedButton.titleLabel.text);
        self.accountType = radioButton.selectedButton.titleLabel.text;
    }
}

#pragma mark - Back Action

- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - User Register

- (IBAction)btnRegister:(id)sender
{
    if ([[self.userName text] length] == 0) {
        [[[UIAlertView alloc] initWithTitle:@"Barber Says" message:@"Please Input Username" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
        [self.userName becomeFirstResponder];
        return;
    }
    if ([[self.userEmail text] length] == 0) {
        [[[UIAlertView alloc] initWithTitle:@"Barber Says" message:@"Please Input E-mail" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
        [self.userEmail becomeFirstResponder];
        return;
    }
    else if ([[self.userPhoneNumber text] length] == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Barber Says" message:@"Please Input PhoneNumber" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
        [self.userPhoneNumber becomeFirstResponder];
        return;
    }
    else if ([[self.password text] length] == 0)
    {
        [[[UIAlertView alloc] initWithTitle:@"Barber Says" message:@"Please Input Password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil] show];
        [self.password becomeFirstResponder];
        return;
    }
    
    else
    {
        [SVProgressHUD showWithStatus:@"Registering..."];
        PFUser *user = [PFUser objectWithClassName:PF_USER_CLASS_NAME];
        
        user.username = self.userEmail.text;
        user.password = self.password.text;
        user[PF_USER_FULLNAME] = [NSString stringWithFormat:@"%@",self.userName.text];
        user[PF_USER_FULLNAME_LOWER] = [[NSString stringWithFormat:@"%@",self.userName.text] lowercaseString];
        NSData *data = UIImageJPEGRepresentation(self.userPhotoImg.image, 0.5);
        PFFile *imageFile = [PFFile fileWithName:PF_USER_PICTURE data:data];
        user[PF_USER_PICTURE] = imageFile;
        user[PF_USER_PHONENUMBER] = self.userPhoneNumber.text;
        user[PF_USER_ADDRESS] = self.userAddress.text;
        
        NSString *lat = [AppDelegate sharedAllDelegate].strLat;
        NSString *log = [AppDelegate sharedAllDelegate].strLong;
        
        NSLog(@"latitude === %@",lat);
        NSLog(@"longitude === %@",log);
        PFGeoPoint *pinPoint = [PFGeoPoint geoPointWithLatitude:[lat doubleValue] longitude:[log doubleValue]];
        user[PF_USER_LOCATION] = pinPoint;
        user[PF_USER_TYPE] = self.accountType;
        
        [user signUpInBackgroundWithBlock:^(BOOL succeeded , NSError *error)
         {
             if(!error)
             {
                 NSLog(@"Register Success");
                 
                 ParsePushUserAssign();
                 [SVProgressHUD dismiss];
                 
                 UIStoryboard *board = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                 UIViewController    *vc = [board instantiateViewControllerWithIdentifier:@"HomeViewController"];
                 [self.navigationController pushViewController:vc animated:YES];
                 
             }
             else
             {
                 [SVProgressHUD dismiss];
             }
         }];
        
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
