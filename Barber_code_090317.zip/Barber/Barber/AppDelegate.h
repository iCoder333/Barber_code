//
//  AppDelegate.h
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse.h>
#import "AppConstant.h"
#import <CoreLocation/CoreLocation.h>
#import "SlideNavigationController.h"
#import "LeftViewController.h"


@interface AppDelegate : UIResponder <UIApplicationDelegate,CLLocationManagerDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) CLLocationManager             *m_locationManager;
@property (strong, nonatomic) CLLocation                    *m_curLocation;
@property (strong, nonatomic) NSString                      *strZipCode;
@property (strong, nonatomic) NSString                      *strCountry;
@property (strong, nonatomic) NSString                      *strRegion;
@property (strong, nonatomic) NSString                      *strCity;
@property (strong, nonatomic) NSString                      *strAddress;

@property (weak, nonatomic) NSString                        *strLong;
@property (weak, nonatomic) NSString                        *strLat;
@property (strong, nonatomic) NSString                      *strFlag;

@property (nonatomic) CLLocationCoordinate2D                coordinate;

+(AppDelegate*)sharedAllDelegate;

@end

