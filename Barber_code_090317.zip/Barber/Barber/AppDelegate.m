//
//  AppDelegate.m
//  Barber
//
//  Created by Vadim Marina on 8/19/17.
//  Copyright © 2017 Alex Buga. All rights reserved.
//

#import "AppDelegate.h"
#import <AddressBook/AddressBook.h>

#define IS_OS_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [Parse initializeWithConfiguration:[ParseClientConfiguration configurationWithBlock:^(id<ParseMutableClientConfiguration> configuration) {
        configuration.applicationId = PARSE_APP_ID;
        configuration.clientKey = PARSE_CLIENT_KEY;
        configuration.server = @"https://parseapi.back4app.com";
        configuration.localDatastoreEnabled = YES; // If you need to enable local data store
        [Parse enableLocalDatastore];
        
    }]];
    
    application.applicationIconBadgeNumber = 0;
    if ([application respondsToSelector:@selector(registerUserNotificationSettings:)]) {
        UIUserNotificationType userNotificationTypes = (UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound);
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:userNotificationTypes categories:nil];
        [application registerUserNotificationSettings:settings];
        [application registerForRemoteNotifications];
    }

    
    [self getUserLocation];

    UIStoryboard *mainStoryboard;
    mainStoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    LeftViewController *leftMenu = (LeftViewController*)[mainStoryboard
                                                         instantiateViewControllerWithIdentifier: @"leftVC7"];
    
    
    [SlideNavigationController sharedInstance].leftMenu = leftMenu;
    [SlideNavigationController sharedInstance].menuRevealAnimationDuration = .28;
    [SlideNavigationController sharedInstance].enableShadow = YES;
    
    
    [self.window makeKeyAndVisible];
    
    return YES;
}

- (void)getUserLocation
{
    self.m_locationManager = [CLLocationManager new];
    self.m_locationManager.delegate = self;
    self.m_locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
    
    if (IS_OS_OR_LATER) {
        [self.m_locationManager requestWhenInUseAuthorization];
        [self.m_locationManager requestAlwaysAuthorization];
    }
    [self.m_locationManager startUpdatingLocation];
}



- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    self.m_curLocation = [locations objectAtIndex:0];
    self.strLat = [NSString stringWithFormat:@"%f" ,self.m_curLocation.coordinate.latitude];
    self.strLong = [NSString stringWithFormat:@"%f",self.m_curLocation.coordinate.longitude];
    
    
    self.coordinate = self.m_curLocation.coordinate;
    
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder reverseGeocodeLocation:self.m_curLocation completionHandler:^(NSArray *placemarks, NSError *error) {
        if (error) {
            NSLog(@"Failed to reverse-geocode: %@", [error localizedDescription]);
            return;
        }
        
        for (CLPlacemark *placemark in placemarks) {
            
            NSString *city = [placemark.addressDictionary objectForKey:(NSString *)kABPersonAddressStateKey];\
            self.strCity = city;
            NSString *regionName = [placemark.addressDictionary objectForKey:(NSString *)kABPersonAddressCityKey];
            self.strRegion = regionName;
            NSString *address = [placemark.addressDictionary objectForKey:(NSString *)kABPersonAddressStreetKey];
            self.strAddress = address;
            NSString *zipcode = [placemark.addressDictionary objectForKey:(NSString *)kABPersonAddressZIPKey];
            self.strZipCode = zipcode;
            NSString *strCountry = [placemark.addressDictionary objectForKey:(NSString *)kABPersonAddressCountryKey];
            self.strCountry = strCountry;
            NSLog(@"country === %@",strCountry);
        }
    }];}

+(AppDelegate*)sharedAllDelegate
{
    return (AppDelegate*)[[UIApplication sharedApplication] delegate];
}

- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    PFInstallation *currentInstallation = [PFInstallation currentInstallation];
    [currentInstallation setDeviceTokenFromData:deviceToken];
    NSLog(@"device token === %@",deviceToken);
    [currentInstallation saveInBackground];
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
